-- phpMyAdmin SQL Dump
-- version 4.7.0
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Jan 12, 2018 at 10:15 PM
-- Server version: 5.6.34-log
-- PHP Version: 7.1.5

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `new_database`
--

-- --------------------------------------------------------

--
-- Table structure for table `dl_commentmeta`
--

CREATE TABLE `dl_commentmeta` (
  `meta_id` bigint(20) UNSIGNED NOT NULL,
  `comment_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- --------------------------------------------------------

--
-- Table structure for table `dl_comments`
--

CREATE TABLE `dl_comments` (
  `comment_ID` bigint(20) UNSIGNED NOT NULL,
  `comment_post_ID` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `comment_author` tinytext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `comment_author_email` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT '0',
  `comment_approved` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_type` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_parent` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `user_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- --------------------------------------------------------

--
-- Table structure for table `dl_db7_forms`
--

CREATE TABLE `dl_db7_forms` (
  `form_id` bigint(20) NOT NULL,
  `form_post_id` bigint(20) NOT NULL,
  `form_value` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `form_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- --------------------------------------------------------

--
-- Table structure for table `dl_duplicator_packages`
--

CREATE TABLE `dl_duplicator_packages` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(250) NOT NULL,
  `hash` varchar(50) NOT NULL,
  `status` int(11) NOT NULL,
  `created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `owner` varchar(60) NOT NULL,
  `package` mediumblob NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `dl_duplicator_packages`
--

INSERT INTO `dl_duplicator_packages` (`id`, `name`, `hash`, `status`, `created`, `owner`, `package`) VALUES
(1, '20171203_desafiolatam', 'aee91e982c4137a56263171203224922', 100, '2017-12-03 22:49:48', 'JoseMatinez1860', 0x4f3a31313a224455505f5061636b616765223a32333a7b733a373a2243726561746564223b733a31393a22323031372d31322d30332032323a34393a3232223b733a373a2256657273696f6e223b733a363a22312e322e3330223b733a393a2256657273696f6e5750223b733a333a22342e39223b733a393a2256657273696f6e4442223b733a363a22352e362e3334223b733a31303a2256657273696f6e504850223b733a353a22372e312e35223b733a393a2256657273696f6e4f53223b733a353a2257494e4e54223b733a323a224944223b693a313b733a343a224e616d65223b733a32313a2232303137313230335f6465736166696f6c6174616d223b733a343a2248617368223b733a33323a226165653931653938326334313337613536323633313731323033323234393232223b733a383a224e616d6548617368223b733a35343a2232303137313230335f6465736166696f6c6174616d5f6165653931653938326334313337613536323633313731323033323234393232223b733a343a2254797065223b693a303b733a353a224e6f746573223b733a303a22223b733a393a2253746f726550617468223b733a35313a22433a2f55736572732f59696e65736b612f4465736b746f702f776f726470726573732f77702d736e617073686f74732f746d70223b733a383a2253746f726555524c223b733a33353a22687474703a2f2f6c6f63616c686f73743a383838382f77702d736e617073686f74732f223b733a383a225363616e46696c65223b733a36343a2232303137313230335f6465736166696f6c6174616d5f61656539316539383263343133376135363236333137313230333232343932325f7363616e2e6a736f6e223b733a373a2252756e74696d65223b733a31313a223130312e3132207365632e223b733a373a2245786553697a65223b733a383a223434332e33324b42223b733a373a225a697053697a65223b733a373a2233332e36374d42223b733a363a22537461747573223b4e3b733a363a22575055736572223b733a31353a224a6f73654d6174696e657a31383630223b733a373a2241726368697665223b4f3a31313a224455505f41726368697665223a31383a7b733a31303a2246696c74657244697273223b733a303a22223b733a31313a2246696c74657246696c6573223b733a303a22223b733a31303a2246696c74657245787473223b733a303a22223b733a31333a2246696c74657244697273416c6c223b613a303a7b7d733a31343a2246696c74657246696c6573416c6c223b613a303a7b7d733a31333a2246696c74657245787473416c6c223b613a303a7b7d733a383a2246696c7465724f6e223b693a303b733a31323a224578706f72744f6e6c794442223b693a303b733a343a2246696c65223b733a36363a2232303137313230335f6465736166696f6c6174616d5f61656539316539383263343133376135363236333137313230333232343932325f617263686976652e7a6970223b733a363a22466f726d6174223b733a333a225a4950223b733a373a225061636b446972223b733a33343a22433a2f55736572732f59696e65736b612f4465736b746f702f776f72647072657373223b733a343a2253697a65223b693a33353330333736373b733a343a2244697273223b613a303a7b7d733a353a2246696c6573223b613a303a7b7d733a31303a2246696c746572496e666f223b4f3a32333a224455505f417263686976655f46696c7465725f496e666f223a383a7b733a343a2244697273223b4f3a33343a224455505f417263686976655f46696c7465725f53636f70655f4469726563746f7279223a343a7b733a373a225761726e696e67223b613a303a7b7d733a31303a22556e7265616461626c65223b613a303a7b7d733a343a22436f7265223b613a303a7b7d733a383a22496e7374616e6365223b613a303a7b7d7d733a353a2246696c6573223b4f3a32393a224455505f417263686976655f46696c7465725f53636f70655f46696c65223a353a7b733a343a2253697a65223b613a303a7b7d733a373a225761726e696e67223b613a303a7b7d733a31303a22556e7265616461626c65223b613a303a7b7d733a343a22436f7265223b613a303a7b7d733a383a22496e7374616e6365223b613a303a7b7d7d733a343a2245787473223b4f3a32393a224455505f417263686976655f46696c7465725f53636f70655f42617365223a323a7b733a343a22436f7265223b613a303a7b7d733a383a22496e7374616e6365223b613a303a7b7d7d733a393a2255446972436f756e74223b693a303b733a31303a225546696c65436f756e74223b693a303b733a393a2255457874436f756e74223b693a303b733a383a225472656553697a65223b613a303a7b7d733a31313a22547265655761726e696e67223b613a303a7b7d7d733a31303a22002a005061636b616765223b723a313b733a32393a22004455505f4172636869766500746d7046696c74657244697273416c6c223b613a303a7b7d733a32343a22004455505f41726368697665007770436f72655061746873223b613a363a7b693a303b733a34333a22433a2f55736572732f59696e65736b612f4465736b746f702f776f726470726573732f77702d61646d696e223b693a313b733a35333a22433a2f55736572732f59696e65736b612f4465736b746f702f776f726470726573732f77702d636f6e74656e742f75706c6f616473223b693a323b733a35353a22433a2f55736572732f59696e65736b612f4465736b746f702f776f726470726573732f77702d636f6e74656e742f6c616e677561676573223b693a333b733a35333a22433a2f55736572732f59696e65736b612f4465736b746f702f776f726470726573732f77702d636f6e74656e742f706c7567696e73223b693a343b733a35323a22433a2f55736572732f59696e65736b612f4465736b746f702f776f726470726573732f77702d636f6e74656e742f7468656d6573223b693a353b733a34363a22433a2f55736572732f59696e65736b612f4465736b746f702f776f726470726573732f77702d696e636c75646573223b7d7d733a393a22496e7374616c6c6572223b4f3a31333a224455505f496e7374616c6c6572223a373a7b733a343a2246696c65223b733a36383a2232303137313230335f6465736166696f6c6174616d5f61656539316539383263343133376135363236333137313230333232343932325f696e7374616c6c65722e706870223b733a343a2253697a65223b693a3435333935363b733a31303a224f7074734442486f7374223b733a303a22223b733a31303a224f7074734442506f7274223b733a303a22223b733a31303a224f70747344424e616d65223b733a303a22223b733a31303a224f707473444255736572223b733a303a22223b733a31303a22002a005061636b616765223b723a313b7d733a383a224461746162617365223b4f3a31323a224455505f4461746162617365223a31333a7b733a343a2254797065223b733a353a224d7953514c223b733a343a2253697a65223b693a3536373331353b733a343a2246696c65223b733a36373a2232303137313230335f6465736166696f6c6174616d5f61656539316539383263343133376135363236333137313230333232343932325f64617461626173652e73716c223b733a343a2250617468223b4e3b733a31323a2246696c7465725461626c6573223b733a303a22223b733a383a2246696c7465724f6e223b693a303b733a343a224e616d65223b4e3b733a31303a22436f6d70617469626c65223b733a303a22223b733a383a22436f6d6d656e7473223b733a32383a224d7953514c20436f6d6d756e69747920536572766572202847504c29223b733a31303a22002a005061636b616765223b723a313b733a32353a22004455505f446174616261736500646253746f726550617468223b733a3131393a22433a2f55736572732f59696e65736b612f4465736b746f702f776f726470726573732f77702d736e617073686f74732f746d702f32303137313230335f6465736166696f6c6174616d5f61656539316539383263343133376135363236333137313230333232343932325f64617461626173652e73716c223b733a32333a22004455505f446174616261736500454f464d61726b6572223b733a303a22223b733a32363a22004455505f4461746162617365006e6574776f726b466c757368223b623a303b7d7d);

-- --------------------------------------------------------

--
-- Table structure for table `dl_ewwwio_images`
--

CREATE TABLE `dl_ewwwio_images` (
  `id` int(14) UNSIGNED NOT NULL,
  `attachment_id` bigint(20) UNSIGNED DEFAULT NULL,
  `gallery` varchar(10) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `resize` varchar(75) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `path` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `converted` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `results` varchar(75) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `image_size` int(10) UNSIGNED DEFAULT NULL,
  `orig_size` int(10) UNSIGNED DEFAULT NULL,
  `backup` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `level` int(5) UNSIGNED DEFAULT NULL,
  `pending` tinyint(1) NOT NULL DEFAULT '0',
  `updates` int(5) UNSIGNED DEFAULT NULL,
  `updated` timestamp NOT NULL DEFAULT '1971-01-01 03:00:00' ON UPDATE CURRENT_TIMESTAMP,
  `trace` blob
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Dumping data for table `dl_ewwwio_images`
--

INSERT INTO `dl_ewwwio_images` (`id`, `attachment_id`, `gallery`, `resize`, `path`, `converted`, `results`, `image_size`, `orig_size`, `backup`, `level`, `pending`, `updates`, `updated`, `trace`) VALUES
(11, NULL, NULL, NULL, 'C:\\Users\\Yineska\\Desktop\\wordpress/wp-content/themes/wp_boilerplate\\assets\\ico\\apple-touch-icon-120x120.png', '', 'Reduced by 24,1% (736,0 B)', 2323, 3059, '', NULL, 0, 1, '2017-11-28 00:39:58', NULL),
(12, NULL, NULL, NULL, 'C:\\Users\\Yineska\\Desktop\\wordpress/wp-content/themes/wp_boilerplate\\assets\\ico\\apple-touch-icon-152x152.png', '', 'Reduced by 24,2% (985,0 B)', 3086, 4071, '', NULL, 0, 1, '2017-11-28 00:39:59', NULL),
(13, NULL, NULL, NULL, 'C:\\Users\\Yineska\\Desktop\\wordpress/wp-content/themes/wp_boilerplate\\assets\\ico\\apple-touch-icon-180x180.png', '', 'Reduced by 21,5% (1,1 KB)', 4230, 5389, '', NULL, 0, 1, '2017-11-28 00:39:59', NULL),
(14, NULL, NULL, NULL, 'C:\\Users\\Yineska\\Desktop\\wordpress/wp-content/themes/wp_boilerplate\\assets\\ico\\apple-touch-icon-76x76.png', '', 'No savings', 1752, 1752, '', NULL, 0, 1, '2017-11-28 00:40:00', NULL),
(15, NULL, NULL, NULL, 'C:\\Users\\Yineska\\Desktop\\wordpress/wp-content/themes/wp_boilerplate\\assets\\ico\\apple-touch-icon.png', '', 'No savings', 1228, 1228, '', NULL, 0, 1, '2017-11-28 00:40:00', NULL),
(16, NULL, NULL, NULL, 'C:\\Users\\Yineska\\Desktop\\wordpress/wp-content/themes/wp_boilerplate\\assets\\ico\\icon-hires.png', '', 'Reduced by 31,7% (2,5 KB)', 5625, 8236, '', NULL, 0, 1, '2017-11-28 00:40:01', NULL),
(17, NULL, NULL, NULL, 'C:\\Users\\Yineska\\Desktop\\wordpress/wp-content/themes/wp_boilerplate\\assets\\ico\\icon-normal.png', '', 'Reduced by 35,4% (2,0 KB)', 3654, 5660, '', NULL, 0, 1, '2017-11-28 00:40:01', NULL),
(18, NULL, NULL, NULL, 'C:\\Users\\Yineska\\Desktop\\wordpress/wp-content/themes/wp_boilerplate\\screenshot.png', '', 'Reduced by 74,8% (19,1 KB)', 6600, 26189, '', NULL, 0, 1, '2017-11-28 00:40:02', NULL),
(109, 157, 'media', 'full', 'C:\\Users\\Yineska\\Desktop\\wordpress/wp-content/uploads/2017/12/camaron.jpeg', '', 'Reduced by 3,6% (5,7 KB)', 159202, 165066, '', NULL, 0, 1, '2017-12-20 20:57:57', NULL),
(110, 157, 'media', 'thumbnail', 'C:\\Users\\Yineska\\Desktop\\wordpress/wp-content/uploads/2017/12/camaron-150x150.jpeg', '', 'No savings', 7092, 7092, '', NULL, 0, 1, '2017-12-20 20:57:57', NULL),
(111, 157, 'media', 'medium', 'C:\\Users\\Yineska\\Desktop\\wordpress/wp-content/uploads/2017/12/camaron-300x225.jpeg', '', 'Reduced by 3,1% (536,0 B)', 16989, 17525, '', NULL, 0, 1, '2017-12-20 20:57:58', NULL),
(112, 157, 'media', 'medium_large', 'C:\\Users\\Yineska\\Desktop\\wordpress/wp-content/uploads/2017/12/camaron-768x576.jpeg', '', 'Reduced by 3,2% (2,6 KB)', 79187, 81835, '', NULL, 0, 1, '2017-12-20 20:57:58', NULL),
(113, 157, 'media', 'large', 'C:\\Users\\Yineska\\Desktop\\wordpress/wp-content/uploads/2017/12/camaron-1024x768.jpeg', '', 'Reduced by 2,9% (3,7 KB)', 125706, 129456, '', NULL, 0, 1, '2017-12-20 20:57:58', NULL),
(114, 157, 'media', 'Size', 'C:\\Users\\Yineska\\Desktop\\wordpress/wp-content/uploads/2017/12/camaron-400x400.jpeg', '', 'Reduced by 3,4% (1,2 KB)', 33989, 35177, '', NULL, 0, 1, '2017-12-20 20:57:59', NULL),
(115, 157, 'media', 'custom_logo', 'C:\\Users\\Yineska\\Desktop\\wordpress/wp-content/uploads/2017/12/camaron-800x600.jpeg', '', 'Reduced by 3,4% (2,9 KB)', 84565, 87546, '', NULL, 0, 1, '2017-12-20 20:57:59', NULL),
(116, 158, 'media', 'full', 'C:\\Users\\Yineska\\Desktop\\wordpress/wp-content/uploads/2017/12/g1.png', '', 'Reduced by 13,3% (63,8 KB)', 424409, 489736, '', NULL, 0, 1, '2017-12-20 20:58:10', NULL),
(117, 158, 'media', 'thumbnail', 'C:\\Users\\Yineska\\Desktop\\wordpress/wp-content/uploads/2017/12/g1-150x150.png', '', 'Reduced by 13,6% (6,8 KB)', 44221, 51160, '', NULL, 0, 1, '2017-12-20 20:58:11', NULL),
(118, 158, 'media', 'medium', 'C:\\Users\\Yineska\\Desktop\\wordpress/wp-content/uploads/2017/12/g1-300x225.png', '', 'Reduced by 13,1% (17,7 KB)', 120723, 138844, '', NULL, 0, 1, '2017-12-20 20:58:12', NULL),
(119, 158, 'media', 'Size', 'C:\\Users\\Yineska\\Desktop\\wordpress/wp-content/uploads/2017/12/g1-400x400.png', '', 'Reduced by 13,5% (37,8 KB)', 248221, 286918, '', NULL, 0, 1, '2017-12-20 20:58:14', NULL),
(120, 159, 'media', 'full', 'C:\\Users\\Yineska\\Desktop\\wordpress/wp-content/uploads/2017/12/Pizza-1.jpg', '', 'Reduced by 10,0% (95,4 KB)', 877679, 975404, '', NULL, 0, 1, '2017-12-20 20:58:20', NULL),
(121, 159, 'media', 'thumbnail', 'C:\\Users\\Yineska\\Desktop\\wordpress/wp-content/uploads/2017/12/Pizza-1-150x150.jpg', '', 'Reduced by 41,0% (5,0 KB)', 7385, 12508, '', NULL, 0, 1, '2017-12-20 20:58:20', NULL),
(122, 159, 'media', 'medium', 'C:\\Users\\Yineska\\Desktop\\wordpress/wp-content/uploads/2017/12/Pizza-1-300x179.jpg', '', 'Reduced by 30,1% (5,3 KB)', 12667, 18132, '', NULL, 0, 1, '2017-12-20 20:58:21', NULL),
(123, 159, 'media', 'medium_large', 'C:\\Users\\Yineska\\Desktop\\wordpress/wp-content/uploads/2017/12/Pizza-1-768x457.jpg', '', 'Reduced by 12,3% (8,5 KB)', 62277, 71020, '', NULL, 0, 1, '2017-12-20 20:58:21', NULL),
(124, 159, 'media', 'large', 'C:\\Users\\Yineska\\Desktop\\wordpress/wp-content/uploads/2017/12/Pizza-1-1024x609.jpg', '', 'Reduced by 9,9% (11,0 KB)', 102464, 113725, '', NULL, 0, 1, '2017-12-20 20:58:21', NULL),
(125, 159, 'media', 'Size', 'C:\\Users\\Yineska\\Desktop\\wordpress/wp-content/uploads/2017/12/Pizza-1-400x400.jpg', '', 'Reduced by 15,6% (6,9 KB)', 38167, 45246, '', NULL, 0, 1, '2017-12-20 20:58:22', NULL),
(126, 159, 'media', 'custom_logo', 'C:\\Users\\Yineska\\Desktop\\wordpress/wp-content/uploads/2017/12/Pizza-1-800x600.jpg', '', 'Reduced by 9,8% (10,0 KB)', 94096, 104324, '', NULL, 0, 1, '2017-12-20 20:58:22', NULL),
(127, 160, 'media', 'full', 'C:\\Users\\Yineska\\Desktop\\wordpress/wp-content/uploads/2017/12/Pizza-1-1.jpg', '', 'Reduced by 10,0% (95,4 KB)', 877679, 975404, '', NULL, 0, 1, '2017-12-20 20:58:32', NULL),
(128, 160, 'media', 'thumbnail', 'C:\\Users\\Yineska\\Desktop\\wordpress/wp-content/uploads/2017/12/Pizza-1-1-150x150.jpg', '', 'Reduced by 41,0% (5,0 KB)', 7385, 12508, '', NULL, 0, 1, '2017-12-20 20:58:32', NULL),
(129, 160, 'media', 'medium', 'C:\\Users\\Yineska\\Desktop\\wordpress/wp-content/uploads/2017/12/Pizza-1-1-300x179.jpg', '', 'Reduced by 30,1% (5,3 KB)', 12667, 18132, '', NULL, 0, 1, '2017-12-20 20:58:32', NULL),
(130, 160, 'media', 'medium_large', 'C:\\Users\\Yineska\\Desktop\\wordpress/wp-content/uploads/2017/12/Pizza-1-1-768x457.jpg', '', 'Reduced by 12,3% (8,5 KB)', 62277, 71020, '', NULL, 0, 1, '2017-12-20 20:58:33', NULL),
(131, 160, 'media', 'large', 'C:\\Users\\Yineska\\Desktop\\wordpress/wp-content/uploads/2017/12/Pizza-1-1-1024x609.jpg', '', 'Reduced by 9,9% (11,0 KB)', 102464, 113725, '', NULL, 0, 1, '2017-12-20 20:58:33', NULL),
(132, 160, 'media', 'Size', 'C:\\Users\\Yineska\\Desktop\\wordpress/wp-content/uploads/2017/12/Pizza-1-1-400x400.jpg', '', 'Reduced by 15,6% (6,9 KB)', 38167, 45246, '', NULL, 0, 1, '2017-12-20 20:58:33', NULL),
(133, 160, 'media', 'custom_logo', 'C:\\Users\\Yineska\\Desktop\\wordpress/wp-content/uploads/2017/12/Pizza-1-1-800x600.jpg', '', 'Reduced by 9,8% (10,0 KB)', 94096, 104324, '', NULL, 0, 1, '2017-12-20 20:58:34', NULL),
(134, 161, 'media', 'full', 'C:\\Users\\Yineska\\Desktop\\wordpress/wp-content/uploads/2017/12/pizza.jpg', '', 'Reduced by 9,5% (23,7 KB)', 232221, 256507, '', NULL, 0, 1, '2017-12-20 20:58:53', NULL),
(135, 161, 'media', 'thumbnail', 'C:\\Users\\Yineska\\Desktop\\wordpress/wp-content/uploads/2017/12/pizza-150x150.jpg', '', 'Reduced by 53,3% (9,5 KB)', 8517, 18242, '', NULL, 0, 1, '2017-12-20 20:58:54', NULL),
(136, 161, 'media', 'medium', 'C:\\Users\\Yineska\\Desktop\\wordpress/wp-content/uploads/2017/12/pizza-300x169.jpg', '', 'Reduced by 37,7% (9,6 KB)', 16304, 26161, '', NULL, 0, 1, '2017-12-20 20:58:54', NULL),
(137, 161, 'media', 'medium_large', 'C:\\Users\\Yineska\\Desktop\\wordpress/wp-content/uploads/2017/12/pizza-768x432.jpg', '', 'Reduced by 13,1% (11,4 KB)', 77381, 89084, '', NULL, 0, 1, '2017-12-20 20:58:54', NULL),
(138, 161, 'media', 'large', 'C:\\Users\\Yineska\\Desktop\\wordpress/wp-content/uploads/2017/12/pizza-1024x576.jpg', '', 'Reduced by 9,3% (12,7 KB)', 126647, 139678, '', NULL, 0, 1, '2017-12-20 20:58:55', NULL),
(139, 161, 'media', 'Size', 'C:\\Users\\Yineska\\Desktop\\wordpress/wp-content/uploads/2017/12/pizza-400x400.jpg', '', 'Reduced by 20,2% (10,6 KB)', 42776, 53590, '', NULL, 0, 1, '2017-12-20 20:58:55', NULL),
(140, 161, 'media', 'custom_logo', 'C:\\Users\\Yineska\\Desktop\\wordpress/wp-content/uploads/2017/12/pizza-800x600.jpg', '', 'Reduced by 10,7% (12,8 KB)', 109555, 122615, '', NULL, 0, 1, '2017-12-20 20:58:55', NULL),
(141, 162, 'media', 'full', 'C:\\Users\\Yineska\\Desktop\\wordpress/wp-content/uploads/2017/12/pizza-.jpg', '', 'Reduced by 5,3% (2,2 KB)', 40353, 42599, '', NULL, 0, 1, '2017-12-20 20:59:08', NULL),
(142, 162, 'media', 'thumbnail', 'C:\\Users\\Yineska\\Desktop\\wordpress/wp-content/uploads/2017/12/pizza--150x150.jpg', '', 'No savings', 7571, 7571, '', NULL, 0, 1, '2017-12-20 20:59:08', NULL),
(143, 162, 'media', 'medium', 'C:\\Users\\Yineska\\Desktop\\wordpress/wp-content/uploads/2017/12/pizza--300x263.jpg', '', 'Reduced by 3,7% (787,0 B)', 20421, 21208, '', NULL, 0, 1, '2017-12-20 20:59:08', NULL),
(144, 162, 'media', 'Size', 'C:\\Users\\Yineska\\Desktop\\wordpress/wp-content/uploads/2017/12/pizza--400x351.jpg', '', 'Reduced by 5,2% (2,0 KB)', 38568, 40664, '', NULL, 0, 1, '2017-12-20 20:59:08', NULL),
(145, 163, 'media', 'full', 'C:\\Users\\Yineska\\Desktop\\wordpress/wp-content/uploads/2017/12/pizzas02.jpg', '', 'Reduced by 5,4% (14,5 KB)', 262805, 277666, '', NULL, 0, 1, '2017-12-20 20:59:13', NULL),
(146, 163, 'media', 'thumbnail', 'C:\\Users\\Yineska\\Desktop\\wordpress/wp-content/uploads/2017/12/pizzas02-150x150.jpg', '', 'Reduced by 2,6% (301,0 B)', 11401, 11702, '', NULL, 0, 1, '2017-12-20 20:59:13', NULL),
(147, 163, 'media', 'medium', 'C:\\Users\\Yineska\\Desktop\\wordpress/wp-content/uploads/2017/12/pizzas02-300x300.jpg', '', 'Reduced by 3,5% (1,3 KB)', 36284, 37609, '', NULL, 0, 1, '2017-12-20 20:59:13', NULL),
(148, 163, 'media', 'medium_large', 'C:\\Users\\Yineska\\Desktop\\wordpress/wp-content/uploads/2017/12/pizzas02-768x768.jpg', '', 'Reduced by 3,1% (5,2 KB)', 165531, 170838, '', NULL, 0, 1, '2017-12-20 20:59:14', NULL),
(149, 163, 'media', 'Size', 'C:\\Users\\Yineska\\Desktop\\wordpress/wp-content/uploads/2017/12/pizzas02-400x400.jpg', '', 'Reduced by 3,3% (1,9 KB)', 57192, 59114, '', NULL, 0, 1, '2017-12-20 20:59:14', NULL),
(150, 163, 'media', 'custom_logo', 'C:\\Users\\Yineska\\Desktop\\wordpress/wp-content/uploads/2017/12/pizzas02-800x600.jpg', '', 'Reduced by 3,8% (6,0 KB)', 154824, 160917, '', NULL, 0, 1, '2017-12-20 20:59:15', NULL),
(151, 164, 'media', 'full', 'C:\\Users\\Yineska\\Desktop\\wordpress/wp-content/uploads/2017/12/verfotoc.jpg', '', 'Reduced by 3,4% (4,7 KB)', 137208, 142010, '', NULL, 0, 1, '2017-12-20 20:59:19', NULL),
(152, 164, 'media', 'thumbnail', 'C:\\Users\\Yineska\\Desktop\\wordpress/wp-content/uploads/2017/12/verfotoc-150x150.jpg', '', 'Reduced by 0,7% (64,0 B)', 8841, 8905, '', NULL, 0, 1, '2017-12-20 20:59:19', NULL),
(153, 164, 'media', 'medium', 'C:\\Users\\Yineska\\Desktop\\wordpress/wp-content/uploads/2017/12/verfotoc-300x300.jpg', '', 'Reduced by 4,8% (1,3 KB)', 26195, 27511, '', NULL, 0, 1, '2017-12-20 20:59:20', NULL),
(154, 164, 'media', 'medium_large', 'C:\\Users\\Yineska\\Desktop\\wordpress/wp-content/uploads/2017/12/verfotoc-768x768.jpg', '', 'Reduced by 3,4% (3,9 KB)', 112197, 116191, '', NULL, 0, 1, '2017-12-20 20:59:20', NULL),
(155, 164, 'media', 'Size', 'C:\\Users\\Yineska\\Desktop\\wordpress/wp-content/uploads/2017/12/verfotoc-400x400.jpg', '', 'Reduced by 4,4% (1,8 KB)', 40910, 42781, '', NULL, 0, 1, '2017-12-20 20:59:21', NULL),
(156, 164, 'media', 'custom_logo', 'C:\\Users\\Yineska\\Desktop\\wordpress/wp-content/uploads/2017/12/verfotoc-800x600.jpg', '', 'Reduced by 3,6% (3,4 KB)', 93224, 96700, '', NULL, 0, 1, '2017-12-20 20:59:21', NULL),
(157, 173, 'media', 'full', 'C:\\Users\\Yineska\\Desktop\\wordpress/wp-content/uploads/2017/12/logoavpn.png', '', 'Reduced by 14,8% (3,7 KB)', 22099, 25926, '', NULL, 0, 1, '2017-12-22 02:39:31', NULL),
(158, 174, 'media', 'full', 'C:\\Users\\Yineska\\Desktop\\wordpress/wp-content/uploads/2017/12/VERACE.png', '', 'Reduced by 39,7% (10,8 KB)', 16797, 27857, '', NULL, 0, 1, '2017-12-22 02:39:56', NULL),
(159, 174, 'media', 'thumbnail', 'C:\\Users\\Yineska\\Desktop\\wordpress/wp-content/uploads/2017/12/VERACE-150x150.png', '', 'Reduced by 18,1% (4,3 KB)', 19850, 24236, '', NULL, 0, 1, '2017-12-22 02:39:56', NULL),
(160, 175, 'media', 'full', 'C:\\Users\\Yineska\\Desktop\\wordpress/wp-content/uploads/2017/12/excelenciatripadvisor.png', '', 'Reduced by 26,4% (9,1 KB)', 26119, 35479, '', NULL, 0, 1, '2017-12-22 02:40:04', NULL),
(161, 175, 'media', 'thumbnail', 'C:\\Users\\Yineska\\Desktop\\wordpress/wp-content/uploads/2017/12/excelenciatripadvisor-150x150.png', '', 'Reduced by 17,1% (2,8 KB)', 13820, 16678, '', NULL, 0, 1, '2017-12-22 02:40:04', NULL),
(162, 175, 'media', 'medium', 'C:\\Users\\Yineska\\Desktop\\wordpress/wp-content/uploads/2017/12/excelenciatripadvisor-233x300.png', '', 'Reduced by 16,5% (5,8 KB)', 29826, 35722, '', NULL, 0, 1, '2017-12-22 02:40:06', NULL),
(163, 176, 'media', 'full', 'C:\\Users\\Yineska\\Desktop\\wordpress/wp-content/uploads/2017/12/certificado-de-excelencia_ESP.png', '', 'Reduced by 20,8% (4,7 KB)', 18292, 23083, '', NULL, 0, 1, '2017-12-22 02:40:44', NULL),
(164, 184, 'media', 'full', 'C:\\Users\\Yineska\\Desktop\\wordpress/wp-content/uploads/2017/12/fc105214e631d6c9f10c73e91815b4fd.jpg', '', 'Reduced by 6,0% (7,2 KB)', 114477, 121823, '', NULL, 0, 1, '2017-12-28 15:41:05', NULL),
(165, 184, 'media', 'full', 'C:\\Users\\Yineska\\Desktop\\wordpress/wp-content/uploads/2017/12/fc105214e631d6c9f10c73e91815b4fd.jpg', '', 'Reduced by 6,0% (7,2 KB)', 114477, 121823, '', NULL, 0, 1, '2017-12-28 15:41:05', NULL),
(166, 184, 'media', 'thumbnail', 'C:\\Users\\Yineska\\Desktop\\wordpress/wp-content/uploads/2017/12/fc105214e631d6c9f10c73e91815b4fd-150x150.jpg', '', 'Reduced by 0,7% (61,0 B)', 8245, 8306, '', NULL, 0, 1, '2017-12-28 15:41:05', NULL),
(167, 184, 'media', 'thumbnail', 'C:\\Users\\Yineska\\Desktop\\wordpress/wp-content/uploads/2017/12/fc105214e631d6c9f10c73e91815b4fd-150x150.jpg', '', 'Reduced by 0,7% (61,0 B)', 8245, 8306, '', NULL, 0, 1, '2017-12-28 15:41:05', NULL),
(168, 184, 'media', 'medium', 'C:\\Users\\Yineska\\Desktop\\wordpress/wp-content/uploads/2017/12/fc105214e631d6c9f10c73e91815b4fd-274x300.jpg', '', 'Reduced by 4,8% (1,3 KB)', 27040, 28418, '', NULL, 0, 1, '2017-12-28 15:41:06', NULL),
(169, 184, 'media', 'Size', 'C:\\Users\\Yineska\\Desktop\\wordpress/wp-content/uploads/2017/12/fc105214e631d6c9f10c73e91815b4fd-400x400.jpg', '', 'Reduced by 6,2% (3,2 KB)', 49809, 53075, '', NULL, 0, 1, '2017-12-28 15:41:06', NULL),
(170, 184, 'media', 'custom_logo', 'C:\\Users\\Yineska\\Desktop\\wordpress/wp-content/uploads/2017/12/fc105214e631d6c9f10c73e91815b4fd-594x600.jpg', '', 'Reduced by 6,1% (7,3 KB)', 113401, 120830, '', NULL, 0, 1, '2017-12-28 15:41:07', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `dl_links`
--

CREATE TABLE `dl_links` (
  `link_id` bigint(20) UNSIGNED NOT NULL,
  `link_url` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_name` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_image` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_target` varchar(25) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_description` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_visible` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'Y',
  `link_owner` bigint(20) UNSIGNED NOT NULL DEFAULT '1',
  `link_rating` int(11) NOT NULL DEFAULT '0',
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_notes` mediumtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `link_rss` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- --------------------------------------------------------

--
-- Table structure for table `dl_options`
--

CREATE TABLE `dl_options` (
  `option_id` bigint(20) UNSIGNED NOT NULL,
  `option_name` varchar(191) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `option_value` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `autoload` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'yes'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Dumping data for table `dl_options`
--

INSERT INTO `dl_options` (`option_id`, `option_name`, `option_value`, `autoload`) VALUES
(1, 'siteurl', 'http://localhost:8888', 'yes'),
(2, 'home', 'http://localhost:8888', 'yes'),
(3, 'blogname', 'DOMANI-Pizza &amp; Bar', 'yes'),
(4, 'blogdescription', 'De Napoli para Chile!', 'yes'),
(5, 'users_can_register', '0', 'yes'),
(6, 'admin_email', 'jose.martinez.mayora@gmail.com', 'yes'),
(7, 'start_of_week', 'Comienzo de la semana', 'yes'),
(8, 'use_balanceTags', '0', 'yes'),
(9, 'use_smilies', '1', 'yes'),
(10, 'require_name_email', '1', 'yes'),
(11, 'comments_notify', '1', 'yes'),
(12, 'posts_per_rss', '10', 'yes'),
(13, 'rss_use_excerpt', '0', 'yes'),
(14, 'mailserver_url', 'mail.example.com', 'yes'),
(15, 'mailserver_login', 'login@example.com', 'yes'),
(16, 'mailserver_pass', 'password', 'yes'),
(17, 'mailserver_port', '110', 'yes'),
(18, 'default_category', '1', 'yes'),
(19, 'default_comment_status', 'open', 'yes'),
(20, 'default_ping_status', 'open', 'yes'),
(21, 'default_pingback_flag', '1', 'yes'),
(22, 'posts_per_page', '10', 'yes'),
(23, 'date_format', 'j F, Y', 'yes'),
(24, 'time_format', 'g:i a', 'yes'),
(25, 'links_updated_date_format', 'j F, Y g:i a', 'yes'),
(26, 'comment_moderation', '0', 'yes'),
(27, 'moderation_notify', '1', 'yes'),
(28, 'permalink_structure', '/%year%/%monthnum%/%day%/%postname%/', 'yes'),
(29, 'rewrite_rules', 'a:136:{s:7:\"news/?$\";s:24:\"index.php?post_type=news\";s:37:\"news/feed/(feed|rdf|rss|rss2|atom)/?$\";s:41:\"index.php?post_type=news&feed=$matches[1]\";s:32:\"news/(feed|rdf|rss|rss2|atom)/?$\";s:41:\"index.php?post_type=news&feed=$matches[1]\";s:24:\"news/page/([0-9]{1,})/?$\";s:42:\"index.php?post_type=news&paged=$matches[1]\";s:10:\"product/?$\";s:27:\"index.php?post_type=product\";s:40:\"product/feed/(feed|rdf|rss|rss2|atom)/?$\";s:44:\"index.php?post_type=product&feed=$matches[1]\";s:35:\"product/(feed|rdf|rss|rss2|atom)/?$\";s:44:\"index.php?post_type=product&feed=$matches[1]\";s:27:\"product/page/([0-9]{1,})/?$\";s:45:\"index.php?post_type=product&paged=$matches[1]\";s:11:\"^wp-json/?$\";s:22:\"index.php?rest_route=/\";s:14:\"^wp-json/(.*)?\";s:33:\"index.php?rest_route=/$matches[1]\";s:21:\"^index.php/wp-json/?$\";s:22:\"index.php?rest_route=/\";s:24:\"^index.php/wp-json/(.*)?\";s:33:\"index.php?rest_route=/$matches[1]\";s:47:\"category/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:52:\"index.php?category_name=$matches[1]&feed=$matches[2]\";s:42:\"category/(.+?)/(feed|rdf|rss|rss2|atom)/?$\";s:52:\"index.php?category_name=$matches[1]&feed=$matches[2]\";s:23:\"category/(.+?)/embed/?$\";s:46:\"index.php?category_name=$matches[1]&embed=true\";s:35:\"category/(.+?)/page/?([0-9]{1,})/?$\";s:53:\"index.php?category_name=$matches[1]&paged=$matches[2]\";s:17:\"category/(.+?)/?$\";s:35:\"index.php?category_name=$matches[1]\";s:44:\"tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?tag=$matches[1]&feed=$matches[2]\";s:39:\"tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?tag=$matches[1]&feed=$matches[2]\";s:20:\"tag/([^/]+)/embed/?$\";s:36:\"index.php?tag=$matches[1]&embed=true\";s:32:\"tag/([^/]+)/page/?([0-9]{1,})/?$\";s:43:\"index.php?tag=$matches[1]&paged=$matches[2]\";s:14:\"tag/([^/]+)/?$\";s:25:\"index.php?tag=$matches[1]\";s:45:\"type/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?post_format=$matches[1]&feed=$matches[2]\";s:40:\"type/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?post_format=$matches[1]&feed=$matches[2]\";s:21:\"type/([^/]+)/embed/?$\";s:44:\"index.php?post_format=$matches[1]&embed=true\";s:33:\"type/([^/]+)/page/?([0-9]{1,})/?$\";s:51:\"index.php?post_format=$matches[1]&paged=$matches[2]\";s:15:\"type/([^/]+)/?$\";s:33:\"index.php?post_format=$matches[1]\";s:32:\"news/[^/]+/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:42:\"news/[^/]+/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:62:\"news/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:57:\"news/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:57:\"news/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:38:\"news/[^/]+/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:21:\"news/([^/]+)/embed/?$\";s:37:\"index.php?news=$matches[1]&embed=true\";s:25:\"news/([^/]+)/trackback/?$\";s:31:\"index.php?news=$matches[1]&tb=1\";s:45:\"news/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?news=$matches[1]&feed=$matches[2]\";s:40:\"news/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?news=$matches[1]&feed=$matches[2]\";s:33:\"news/([^/]+)/page/?([0-9]{1,})/?$\";s:44:\"index.php?news=$matches[1]&paged=$matches[2]\";s:40:\"news/([^/]+)/comment-page-([0-9]{1,})/?$\";s:44:\"index.php?news=$matches[1]&cpage=$matches[2]\";s:29:\"news/([^/]+)(?:/([0-9]+))?/?$\";s:43:\"index.php?news=$matches[1]&page=$matches[2]\";s:21:\"news/[^/]+/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:31:\"news/[^/]+/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:51:\"news/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:46:\"news/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:46:\"news/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:27:\"news/[^/]+/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:35:\"product/[^/]+/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:45:\"product/[^/]+/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:65:\"product/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:60:\"product/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:60:\"product/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:41:\"product/[^/]+/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:24:\"product/([^/]+)/embed/?$\";s:40:\"index.php?product=$matches[1]&embed=true\";s:28:\"product/([^/]+)/trackback/?$\";s:34:\"index.php?product=$matches[1]&tb=1\";s:48:\"product/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:46:\"index.php?product=$matches[1]&feed=$matches[2]\";s:43:\"product/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:46:\"index.php?product=$matches[1]&feed=$matches[2]\";s:36:\"product/([^/]+)/page/?([0-9]{1,})/?$\";s:47:\"index.php?product=$matches[1]&paged=$matches[2]\";s:43:\"product/([^/]+)/comment-page-([0-9]{1,})/?$\";s:47:\"index.php?product=$matches[1]&cpage=$matches[2]\";s:32:\"product/([^/]+)(?:/([0-9]+))?/?$\";s:46:\"index.php?product=$matches[1]&page=$matches[2]\";s:24:\"product/[^/]+/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:34:\"product/[^/]+/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:54:\"product/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:49:\"product/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:49:\"product/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:30:\"product/[^/]+/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:12:\"robots\\.txt$\";s:18:\"index.php?robots=1\";s:48:\".*wp-(atom|rdf|rss|rss2|feed|commentsrss2)\\.php$\";s:18:\"index.php?feed=old\";s:20:\".*wp-app\\.php(/.*)?$\";s:19:\"index.php?error=403\";s:18:\".*wp-register.php$\";s:23:\"index.php?register=true\";s:32:\"feed/(feed|rdf|rss|rss2|atom)/?$\";s:27:\"index.php?&feed=$matches[1]\";s:27:\"(feed|rdf|rss|rss2|atom)/?$\";s:27:\"index.php?&feed=$matches[1]\";s:8:\"embed/?$\";s:21:\"index.php?&embed=true\";s:20:\"page/?([0-9]{1,})/?$\";s:28:\"index.php?&paged=$matches[1]\";s:41:\"comments/feed/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?&feed=$matches[1]&withcomments=1\";s:36:\"comments/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?&feed=$matches[1]&withcomments=1\";s:17:\"comments/embed/?$\";s:21:\"index.php?&embed=true\";s:44:\"search/(.+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:40:\"index.php?s=$matches[1]&feed=$matches[2]\";s:39:\"search/(.+)/(feed|rdf|rss|rss2|atom)/?$\";s:40:\"index.php?s=$matches[1]&feed=$matches[2]\";s:20:\"search/(.+)/embed/?$\";s:34:\"index.php?s=$matches[1]&embed=true\";s:32:\"search/(.+)/page/?([0-9]{1,})/?$\";s:41:\"index.php?s=$matches[1]&paged=$matches[2]\";s:14:\"search/(.+)/?$\";s:23:\"index.php?s=$matches[1]\";s:47:\"author/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?author_name=$matches[1]&feed=$matches[2]\";s:42:\"author/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?author_name=$matches[1]&feed=$matches[2]\";s:23:\"author/([^/]+)/embed/?$\";s:44:\"index.php?author_name=$matches[1]&embed=true\";s:35:\"author/([^/]+)/page/?([0-9]{1,})/?$\";s:51:\"index.php?author_name=$matches[1]&paged=$matches[2]\";s:17:\"author/([^/]+)/?$\";s:33:\"index.php?author_name=$matches[1]\";s:69:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:80:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]\";s:64:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$\";s:80:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]\";s:45:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/embed/?$\";s:74:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&embed=true\";s:57:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/page/?([0-9]{1,})/?$\";s:81:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&paged=$matches[4]\";s:39:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/?$\";s:63:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]\";s:56:\"([0-9]{4})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:64:\"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]\";s:51:\"([0-9]{4})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$\";s:64:\"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]\";s:32:\"([0-9]{4})/([0-9]{1,2})/embed/?$\";s:58:\"index.php?year=$matches[1]&monthnum=$matches[2]&embed=true\";s:44:\"([0-9]{4})/([0-9]{1,2})/page/?([0-9]{1,})/?$\";s:65:\"index.php?year=$matches[1]&monthnum=$matches[2]&paged=$matches[3]\";s:26:\"([0-9]{4})/([0-9]{1,2})/?$\";s:47:\"index.php?year=$matches[1]&monthnum=$matches[2]\";s:43:\"([0-9]{4})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?year=$matches[1]&feed=$matches[2]\";s:38:\"([0-9]{4})/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?year=$matches[1]&feed=$matches[2]\";s:19:\"([0-9]{4})/embed/?$\";s:37:\"index.php?year=$matches[1]&embed=true\";s:31:\"([0-9]{4})/page/?([0-9]{1,})/?$\";s:44:\"index.php?year=$matches[1]&paged=$matches[2]\";s:13:\"([0-9]{4})/?$\";s:26:\"index.php?year=$matches[1]\";s:58:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:68:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:88:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:83:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:83:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:64:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:53:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/embed/?$\";s:91:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&embed=true\";s:57:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/trackback/?$\";s:85:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&tb=1\";s:77:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:97:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&feed=$matches[5]\";s:72:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:97:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&feed=$matches[5]\";s:65:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/page/?([0-9]{1,})/?$\";s:98:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&paged=$matches[5]\";s:72:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/comment-page-([0-9]{1,})/?$\";s:98:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&cpage=$matches[5]\";s:61:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)(?:/([0-9]+))?/?$\";s:97:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&page=$matches[5]\";s:47:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:57:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:77:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:72:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:72:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:53:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:64:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/comment-page-([0-9]{1,})/?$\";s:81:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&cpage=$matches[4]\";s:51:\"([0-9]{4})/([0-9]{1,2})/comment-page-([0-9]{1,})/?$\";s:65:\"index.php?year=$matches[1]&monthnum=$matches[2]&cpage=$matches[3]\";s:38:\"([0-9]{4})/comment-page-([0-9]{1,})/?$\";s:44:\"index.php?year=$matches[1]&cpage=$matches[2]\";s:27:\".?.+?/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:37:\".?.+?/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:57:\".?.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:52:\".?.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:52:\".?.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:33:\".?.+?/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:16:\"(.?.+?)/embed/?$\";s:41:\"index.php?pagename=$matches[1]&embed=true\";s:20:\"(.?.+?)/trackback/?$\";s:35:\"index.php?pagename=$matches[1]&tb=1\";s:40:\"(.?.+?)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:47:\"index.php?pagename=$matches[1]&feed=$matches[2]\";s:35:\"(.?.+?)/(feed|rdf|rss|rss2|atom)/?$\";s:47:\"index.php?pagename=$matches[1]&feed=$matches[2]\";s:28:\"(.?.+?)/page/?([0-9]{1,})/?$\";s:48:\"index.php?pagename=$matches[1]&paged=$matches[2]\";s:35:\"(.?.+?)/comment-page-([0-9]{1,})/?$\";s:48:\"index.php?pagename=$matches[1]&cpage=$matches[2]\";s:24:\"(.?.+?)(?:/([0-9]+))?/?$\";s:47:\"index.php?pagename=$matches[1]&page=$matches[2]\";}', 'yes'),
(30, 'hack_file', '0', 'yes'),
(31, 'blog_charset', 'UTF-8', 'yes'),
(32, 'moderation_keys', '', 'no'),
(33, 'active_plugins', 'a:7:{i:0;s:30:\"advanced-custom-fields/acf.php\";i:1;s:36:\"contact-form-7/wp-contact-form-7.php\";i:2;s:42:\"contact-form-cfdb7/contact-form-cfdb-7.php\";i:3;s:25:\"duplicator/duplicator.php\";i:4;s:45:\"ewww-image-optimizer/ewww-image-optimizer.php\";i:5;s:29:\"pdf-embedder/pdf_embedder.php\";i:6;s:37:\"tinymce-advanced/tinymce-advanced.php\";}', 'yes'),
(34, 'category_base', '', 'yes'),
(35, 'ping_sites', 'http://rpc.pingomatic.com/', 'yes'),
(36, 'comment_max_links', '2', 'yes'),
(37, 'gmt_offset', '-6', 'yes'),
(38, 'default_email_category', '1', 'yes'),
(39, 'recently_edited', '', 'no'),
(40, 'template', 'wp_boilerplate', 'yes'),
(41, 'stylesheet', 'wp_boilerplate', 'yes'),
(42, 'comment_whitelist', '1', 'yes'),
(43, 'blacklist_keys', '', 'no'),
(44, 'comment_registration', '0', 'yes'),
(45, 'html_type', 'text/html', 'yes'),
(46, 'use_trackback', '0', 'yes'),
(47, 'default_role', 'subscriber', 'yes'),
(48, 'db_version', '38590', 'yes'),
(49, 'uploads_use_yearmonth_folders', '1', 'yes'),
(50, 'upload_path', '', 'yes'),
(51, 'blog_public', '1', 'yes'),
(52, 'default_link_category', '2', 'yes'),
(53, 'show_on_front', 'posts', 'yes'),
(54, 'tag_base', '', 'yes'),
(55, 'show_avatars', '1', 'yes'),
(56, 'avatar_rating', 'G', 'yes'),
(57, 'upload_url_path', '', 'yes'),
(58, 'thumbnail_size_w', '150', 'yes'),
(59, 'thumbnail_size_h', '150', 'yes'),
(60, 'thumbnail_crop', '1', 'yes'),
(61, 'medium_size_w', '300', 'yes'),
(62, 'medium_size_h', '300', 'yes'),
(63, 'avatar_default', 'mystery', 'yes'),
(64, 'large_size_w', '1024', 'yes'),
(65, 'large_size_h', '1024', 'yes'),
(66, 'image_default_link_type', 'none', 'yes'),
(67, 'image_default_size', '', 'yes'),
(68, 'image_default_align', '', 'yes'),
(69, 'close_comments_for_old_posts', '0', 'yes'),
(70, 'close_comments_days_old', '14', 'yes'),
(71, 'thread_comments', '1', 'yes'),
(72, 'thread_comments_depth', '5', 'yes'),
(73, 'page_comments', '0', 'yes'),
(74, 'comments_per_page', '50', 'yes'),
(75, 'default_comments_page', 'newest', 'yes'),
(76, 'comment_order', 'asc', 'yes'),
(77, 'sticky_posts', 'a:0:{}', 'yes'),
(78, 'widget_categories', 'a:2:{i:2;a:4:{s:5:\"title\";s:0:\"\";s:5:\"count\";i:0;s:12:\"hierarchical\";i:0;s:8:\"dropdown\";i:0;}s:12:\"_multiwidget\";i:1;}', 'yes'),
(79, 'widget_text', 'a:3:{i:1;a:0:{}i:2;a:4:{s:5:\"title\";s:0:\"\";s:4:\"text\";s:47:\"[contact-form-7 id=\"36\" title=\"Contact form 1\"]\";s:6:\"filter\";b:1;s:6:\"visual\";b:1;}s:12:\"_multiwidget\";i:1;}', 'yes'),
(80, 'widget_rss', 'a:2:{i:1;a:0:{}s:12:\"_multiwidget\";i:1;}', 'yes'),
(81, 'uninstall_plugins', 'a:1:{s:45:\"ewww-image-optimizer/ewww-image-optimizer.php\";s:30:\"ewww_image_optimizer_uninstall\";}', 'no'),
(82, 'timezone_string', '', 'yes'),
(83, 'page_for_posts', '0', 'yes'),
(84, 'page_on_front', '0', 'yes'),
(85, 'default_post_format', '0', 'yes'),
(86, 'link_manager_enabled', '0', 'yes'),
(87, 'finished_splitting_shared_terms', '1', 'yes'),
(88, 'site_icon', '0', 'yes'),
(89, 'medium_large_size_w', '768', 'yes'),
(90, 'medium_large_size_h', '0', 'yes'),
(91, 'initial_db_version', '38590', 'yes'),
(92, 'dl_user_roles', 'a:5:{s:13:\"administrator\";a:2:{s:4:\"name\";s:13:\"Administrator\";s:12:\"capabilities\";a:61:{s:13:\"switch_themes\";b:1;s:11:\"edit_themes\";b:1;s:16:\"activate_plugins\";b:1;s:12:\"edit_plugins\";b:1;s:10:\"edit_users\";b:1;s:10:\"edit_files\";b:1;s:14:\"manage_options\";b:1;s:17:\"moderate_comments\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:12:\"upload_files\";b:1;s:6:\"import\";b:1;s:15:\"unfiltered_html\";b:1;s:10:\"edit_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:10:\"edit_pages\";b:1;s:4:\"read\";b:1;s:8:\"level_10\";b:1;s:7:\"level_9\";b:1;s:7:\"level_8\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:17:\"edit_others_pages\";b:1;s:20:\"edit_published_pages\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_pages\";b:1;s:19:\"delete_others_pages\";b:1;s:22:\"delete_published_pages\";b:1;s:12:\"delete_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:22:\"delete_published_posts\";b:1;s:20:\"delete_private_posts\";b:1;s:18:\"edit_private_posts\";b:1;s:18:\"read_private_posts\";b:1;s:20:\"delete_private_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"read_private_pages\";b:1;s:12:\"delete_users\";b:1;s:12:\"create_users\";b:1;s:17:\"unfiltered_upload\";b:1;s:14:\"edit_dashboard\";b:1;s:14:\"update_plugins\";b:1;s:14:\"delete_plugins\";b:1;s:15:\"install_plugins\";b:1;s:13:\"update_themes\";b:1;s:14:\"install_themes\";b:1;s:11:\"update_core\";b:1;s:10:\"list_users\";b:1;s:12:\"remove_users\";b:1;s:13:\"promote_users\";b:1;s:18:\"edit_theme_options\";b:1;s:13:\"delete_themes\";b:1;s:6:\"export\";b:1;}}s:6:\"editor\";a:2:{s:4:\"name\";s:6:\"Editor\";s:12:\"capabilities\";a:34:{s:17:\"moderate_comments\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:12:\"upload_files\";b:1;s:15:\"unfiltered_html\";b:1;s:10:\"edit_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:10:\"edit_pages\";b:1;s:4:\"read\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:17:\"edit_others_pages\";b:1;s:20:\"edit_published_pages\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_pages\";b:1;s:19:\"delete_others_pages\";b:1;s:22:\"delete_published_pages\";b:1;s:12:\"delete_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:22:\"delete_published_posts\";b:1;s:20:\"delete_private_posts\";b:1;s:18:\"edit_private_posts\";b:1;s:18:\"read_private_posts\";b:1;s:20:\"delete_private_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"read_private_pages\";b:1;}}s:6:\"author\";a:2:{s:4:\"name\";s:6:\"Author\";s:12:\"capabilities\";a:10:{s:12:\"upload_files\";b:1;s:10:\"edit_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:4:\"read\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:12:\"delete_posts\";b:1;s:22:\"delete_published_posts\";b:1;}}s:11:\"contributor\";a:2:{s:4:\"name\";s:11:\"Contributor\";s:12:\"capabilities\";a:5:{s:10:\"edit_posts\";b:1;s:4:\"read\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:12:\"delete_posts\";b:1;}}s:10:\"subscriber\";a:2:{s:4:\"name\";s:10:\"Subscriber\";s:12:\"capabilities\";a:2:{s:4:\"read\";b:1;s:7:\"level_0\";b:1;}}}', 'yes'),
(93, 'fresh_site', '0', 'yes'),
(94, 'WPLANG', 'es_VE', 'yes'),
(95, 'widget_search', 'a:3:{i:2;a:1:{s:5:\"title\";s:0:\"\";}i:3;a:1:{s:5:\"title\";s:0:\"\";}s:12:\"_multiwidget\";i:1;}', 'yes'),
(96, 'widget_recent-posts', 'a:2:{i:2;a:2:{s:5:\"title\";s:0:\"\";s:6:\"number\";i:5;}s:12:\"_multiwidget\";i:1;}', 'yes'),
(97, 'widget_recent-comments', 'a:2:{i:2;a:2:{s:5:\"title\";s:0:\"\";s:6:\"number\";i:5;}s:12:\"_multiwidget\";i:1;}', 'yes'),
(98, 'widget_archives', 'a:2:{i:2;a:3:{s:5:\"title\";s:0:\"\";s:5:\"count\";i:0;s:8:\"dropdown\";i:0;}s:12:\"_multiwidget\";i:1;}', 'yes'),
(99, 'widget_meta', 'a:2:{i:2;a:1:{s:5:\"title\";s:0:\"\";}s:12:\"_multiwidget\";i:1;}', 'yes'),
(100, 'sidebars_widgets', 'a:4:{s:19:\"wp_inactive_widgets\";a:10:{i:0;s:8:\"search-2\";i:1;s:14:\"recent-posts-2\";i:2;s:17:\"recent-comments-2\";i:3;s:10:\"archives-2\";i:4;s:12:\"categories-2\";i:5;s:6:\"meta-2\";i:6;s:6:\"text-2\";i:7;s:10:\"nav_menu-2\";i:8;s:13:\"media_image-2\";i:9;s:8:\"search-3\";}s:14:\"sidebar_widget\";a:0:{}s:14:\"contact_widget\";a:0:{}s:13:\"array_version\";i:3;}', 'yes'),
(101, 'widget_pages', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(102, 'widget_calendar', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(103, 'widget_media_audio', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(104, 'widget_media_image', 'a:2:{i:2;a:15:{s:13:\"attachment_id\";i:0;s:3:\"url\";s:0:\"\";s:5:\"title\";s:0:\"\";s:4:\"size\";s:6:\"medium\";s:5:\"width\";i:0;s:6:\"height\";i:0;s:7:\"caption\";s:0:\"\";s:3:\"alt\";s:0:\"\";s:9:\"link_type\";s:6:\"custom\";s:8:\"link_url\";s:0:\"\";s:13:\"image_classes\";s:0:\"\";s:12:\"link_classes\";s:0:\"\";s:8:\"link_rel\";s:0:\"\";s:17:\"link_target_blank\";b:0;s:11:\"image_title\";s:0:\"\";}s:12:\"_multiwidget\";i:1;}', 'yes'),
(105, 'widget_media_gallery', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(106, 'widget_media_video', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(107, 'widget_tag_cloud', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(108, 'widget_nav_menu', 'a:2:{i:2;a:1:{s:8:\"nav_menu\";i:2;}s:12:\"_multiwidget\";i:1;}', 'yes'),
(109, 'widget_custom_html', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(110, 'cron', 'a:4:{i:1515796955;a:3:{s:16:\"wp_version_check\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}s:17:\"wp_update_plugins\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}s:16:\"wp_update_themes\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}}i:1515796994;a:2:{s:19:\"wp_scheduled_delete\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}s:25:\"delete_expired_transients\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1515800377;a:1:{s:30:\"wp_scheduled_auto_draft_delete\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}s:7:\"version\";i:2;}', 'yes'),
(111, 'theme_mods_twentyseventeen', 'a:3:{s:18:\"custom_css_post_id\";i:-1;s:16:\"sidebars_widgets\";a:2:{s:4:\"time\";i:1512922393;s:4:\"data\";a:4:{s:19:\"wp_inactive_widgets\";a:8:{i:0;s:8:\"search-2\";i:1;s:14:\"recent-posts-2\";i:2;s:17:\"recent-comments-2\";i:3;s:10:\"archives-2\";i:4;s:12:\"categories-2\";i:5;s:6:\"meta-2\";i:6;s:6:\"text-2\";i:7;s:10:\"nav_menu-2\";}s:9:\"sidebar-1\";a:0:{}s:9:\"sidebar-2\";a:0:{}s:9:\"sidebar-3\";a:0:{}}}s:18:\"nav_menu_locations\";a:1:{s:3:\"top\";i:2;}}', 'yes'),
(126, 'can_compress_scripts', '0', 'no'),
(141, 'recently_activated', 'a:0:{}', 'yes'),
(150, 'theme_mods_miprimertema', 'a:3:{s:18:\"custom_css_post_id\";i:-1;s:18:\"nav_menu_locations\";a:0:{}s:16:\"sidebars_widgets\";a:2:{s:4:\"time\";i:1512998084;s:4:\"data\";a:1:{s:19:\"wp_inactive_widgets\";a:10:{i:0;s:8:\"search-2\";i:1;s:14:\"recent-posts-2\";i:2;s:17:\"recent-comments-2\";i:3;s:10:\"archives-2\";i:4;s:12:\"categories-2\";i:5;s:6:\"meta-2\";i:6;s:6:\"text-2\";i:7;s:10:\"nav_menu-2\";i:8;s:13:\"media_image-2\";i:9;s:8:\"search-3\";}}}}', 'yes'),
(151, 'current_theme', 'Desafío Latam', 'yes'),
(152, 'theme_switched', '', 'yes'),
(173, 'theme_mods_twentyfifteen', 'a:4:{i:0;b:0;s:18:\"nav_menu_locations\";a:0:{}s:18:\"custom_css_post_id\";i:-1;s:16:\"sidebars_widgets\";a:2:{s:4:\"time\";i:1511913481;s:4:\"data\";a:2:{s:19:\"wp_inactive_widgets\";a:7:{i:0;s:8:\"search-2\";i:1;s:14:\"recent-posts-2\";i:2;s:17:\"recent-comments-2\";i:3;s:10:\"archives-2\";i:4;s:12:\"categories-2\";i:5;s:6:\"meta-2\";i:6;s:6:\"text-2\";}s:9:\"sidebar-1\";a:1:{i:0;s:10:\"nav_menu-2\";}}}}', 'yes'),
(174, '_transient_twentyfifteen_categories', '1', 'yes'),
(193, 'theme_mods_landingpages', 'a:4:{i:0;b:0;s:18:\"nav_menu_locations\";a:0:{}s:16:\"sidebars_widgets\";a:2:{s:4:\"time\";i:1512078368;s:4:\"data\";a:1:{s:19:\"wp_inactive_widgets\";a:8:{i:0;s:8:\"search-2\";i:1;s:14:\"recent-posts-2\";i:2;s:17:\"recent-comments-2\";i:3;s:10:\"archives-2\";i:4;s:12:\"categories-2\";i:5;s:6:\"meta-2\";i:6;s:6:\"text-2\";i:7;s:10:\"nav_menu-2\";}}}s:18:\"custom_css_post_id\";i:-1;}', 'yes'),
(268, 'theme_mods_wp_boilerplate', 'a:4:{i:0;b:0;s:18:\"nav_menu_locations\";a:1:{s:11:\"header-menu\";i:2;}s:18:\"custom_css_post_id\";i:-1;s:16:\"sidebars_widgets\";a:2:{s:4:\"time\";i:1513108366;s:4:\"data\";a:3:{s:19:\"wp_inactive_widgets\";a:10:{i:0;s:8:\"search-2\";i:1;s:14:\"recent-posts-2\";i:2;s:17:\"recent-comments-2\";i:3;s:10:\"archives-2\";i:4;s:12:\"categories-2\";i:5;s:6:\"meta-2\";i:6;s:6:\"text-2\";i:7;s:10:\"nav_menu-2\";i:8;s:13:\"media_image-2\";i:9;s:8:\"search-3\";}s:14:\"sidebar_widget\";a:0:{}s:14:\"contact_widget\";a:0:{}}}}', 'yes'),
(304, 'nav_menu_options', 'a:2:{i:0;b:0;s:8:\"auto_add\";a:0:{}}', 'yes'),
(322, 'acf_version', '4.4.12', 'yes'),
(358, 'ewww_image_optimizer_background_optimization', '1', 'yes'),
(359, 'ewww_image_optimizer_bulk_attachments', '', 'no'),
(360, 'ewww_image_optimizer_flag_attachments', '', 'no'),
(361, 'ewww_image_optimizer_ngg_attachments', '', 'no'),
(362, 'ewww_image_optimizer_disable_pngout', '1', 'no'),
(363, 'ewww_image_optimizer_optipng_level', '2', 'no'),
(364, 'ewww_image_optimizer_pngout_level', '2', 'no'),
(365, 'ewww_image_optimizer_jpegtran_copy', '1', 'no'),
(366, 'ewww_image_optimizer_jpg_level', '10', 'no'),
(367, 'ewww_image_optimizer_png_level', '10', 'no'),
(368, 'ewww_image_optimizer_gif_level', '10', 'no'),
(369, 'ewww_image_optimizer_pdf_level', '0', 'no'),
(370, 'ewww_image_optimizer_version', '403.0', 'yes'),
(371, 'ewww_image_optimizer_tracking_notice', '1', 'yes'),
(378, 'ewww_image_optimizer_scanning_attachments', 'a:0:{}', 'no'),
(379, 'ewww_image_optimizer_bulk_resume', '', 'yes'),
(384, 'ewww_image_optimizer_aux_resume', '', 'yes'),
(385, 'ewww_image_optimizer_aux_folders_completed', 'a:0:{}', 'no'),
(390, 'wpcf7', 'a:2:{s:7:\"version\";s:5:\"4.9.1\";s:13:\"bulk_validate\";a:4:{s:9:\"timestamp\";i:1511808233;s:7:\"version\";s:5:\"4.9.1\";s:11:\"count_valid\";i:1;s:13:\"count_invalid\";i:0;}}', 'yes'),
(395, 'cfdb7_view_install_date', '2017-11-28 0:59:04', 'yes'),
(396, 'widget_akismet_widget', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(462, '_transient_twentyseventeen_categories', '1', 'yes'),
(484, 'theme_mods_affluent', 'a:4:{i:0;b:0;s:18:\"nav_menu_locations\";a:2:{s:9:\"main_menu\";i:2;s:11:\"footer_menu\";i:2;}s:18:\"custom_css_post_id\";i:-1;s:16:\"sidebars_widgets\";a:2:{s:4:\"time\";i:1512602652;s:4:\"data\";a:5:{s:19:\"wp_inactive_widgets\";a:7:{i:0;s:8:\"search-2\";i:1;s:14:\"recent-posts-2\";i:2;s:17:\"recent-comments-2\";i:3;s:10:\"archives-2\";i:4;s:12:\"categories-2\";i:5;s:6:\"meta-2\";i:6;s:6:\"text-2\";}s:15:\"primary-widgets\";a:1:{i:0;s:10:\"nav_menu-2\";}s:16:\"footer-widgets-1\";a:0:{}s:16:\"footer-widgets-2\";a:0:{}s:16:\"footer-widgets-3\";a:0:{}}}}', 'yes'),
(485, 'epsilon_framework_update', '1', 'yes'),
(486, 'cpotheme_settings', 'a:1:{s:24:\"affluent_activation_time\";i:1512079592;}', 'yes'),
(544, 'wp_ewwwio_media_optimize_batch_a', '', 'no'),
(609, 'duplicator_settings', 'a:10:{s:7:\"version\";s:6:\"1.2.30\";s:18:\"uninstall_settings\";b:1;s:15:\"uninstall_files\";b:1;s:16:\"uninstall_tables\";b:1;s:13:\"package_debug\";b:0;s:17:\"package_mysqldump\";b:1;s:22:\"package_mysqldump_path\";s:0:\"\";s:24:\"package_phpdump_qrylimit\";s:3:\"100\";s:17:\"package_zip_flush\";b:0;s:20:\"storage_htaccess_off\";b:0;}', 'yes'),
(610, 'duplicator_version_plugin', '1.2.30', 'yes'),
(611, 'duplicator_ui_view_state', 'a:3:{s:28:\"dup-settings-diag-opts-panel\";s:1:\"1\";s:22:\"dup-pack-storage-panel\";s:1:\"1\";s:22:\"dup-pack-archive-panel\";s:1:\"0\";}', 'yes'),
(612, 'duplicator_package_active', 'O:11:\"DUP_Package\":23:{s:7:\"Created\";s:19:\"2017-12-03 22:49:22\";s:7:\"Version\";s:6:\"1.2.30\";s:9:\"VersionWP\";s:3:\"4.9\";s:9:\"VersionDB\";s:6:\"5.6.34\";s:10:\"VersionPHP\";s:5:\"7.1.5\";s:9:\"VersionOS\";s:5:\"WINNT\";s:2:\"ID\";N;s:4:\"Name\";s:21:\"20171203_desafiolatam\";s:4:\"Hash\";s:32:\"aee91e982c4137a56263171203224922\";s:8:\"NameHash\";s:54:\"20171203_desafiolatam_aee91e982c4137a56263171203224922\";s:4:\"Type\";i:0;s:5:\"Notes\";s:0:\"\";s:9:\"StorePath\";s:51:\"C:/Users/Yineska/Desktop/wordpress/wp-snapshots/tmp\";s:8:\"StoreURL\";s:35:\"http://localhost:8888/wp-snapshots/\";s:8:\"ScanFile\";s:64:\"20171203_desafiolatam_aee91e982c4137a56263171203224922_scan.json\";s:7:\"Runtime\";N;s:7:\"ExeSize\";N;s:7:\"ZipSize\";N;s:6:\"Status\";N;s:6:\"WPUser\";N;s:7:\"Archive\";O:11:\"DUP_Archive\":18:{s:10:\"FilterDirs\";s:0:\"\";s:11:\"FilterFiles\";s:0:\"\";s:10:\"FilterExts\";s:0:\"\";s:13:\"FilterDirsAll\";a:0:{}s:14:\"FilterFilesAll\";a:0:{}s:13:\"FilterExtsAll\";a:0:{}s:8:\"FilterOn\";i:0;s:12:\"ExportOnlyDB\";i:0;s:4:\"File\";N;s:6:\"Format\";s:3:\"ZIP\";s:7:\"PackDir\";s:34:\"C:/Users/Yineska/Desktop/wordpress\";s:4:\"Size\";i:0;s:4:\"Dirs\";a:0:{}s:5:\"Files\";a:0:{}s:10:\"FilterInfo\";O:23:\"DUP_Archive_Filter_Info\":8:{s:4:\"Dirs\";O:34:\"DUP_Archive_Filter_Scope_Directory\":4:{s:7:\"Warning\";a:0:{}s:10:\"Unreadable\";a:0:{}s:4:\"Core\";a:0:{}s:8:\"Instance\";a:0:{}}s:5:\"Files\";O:29:\"DUP_Archive_Filter_Scope_File\":5:{s:4:\"Size\";a:0:{}s:7:\"Warning\";a:0:{}s:10:\"Unreadable\";a:0:{}s:4:\"Core\";a:0:{}s:8:\"Instance\";a:0:{}}s:4:\"Exts\";O:29:\"DUP_Archive_Filter_Scope_Base\":2:{s:4:\"Core\";a:0:{}s:8:\"Instance\";a:0:{}}s:9:\"UDirCount\";i:0;s:10:\"UFileCount\";i:0;s:9:\"UExtCount\";i:0;s:8:\"TreeSize\";a:0:{}s:11:\"TreeWarning\";a:0:{}}s:10:\"\0*\0Package\";O:11:\"DUP_Package\":23:{s:7:\"Created\";s:19:\"2017-12-03 22:49:22\";s:7:\"Version\";s:6:\"1.2.30\";s:9:\"VersionWP\";s:3:\"4.9\";s:9:\"VersionDB\";s:6:\"5.6.34\";s:10:\"VersionPHP\";s:5:\"7.1.5\";s:9:\"VersionOS\";s:5:\"WINNT\";s:2:\"ID\";N;s:4:\"Name\";s:21:\"20171203_desafiolatam\";s:4:\"Hash\";s:32:\"aee91e982c4137a56263171203224922\";s:8:\"NameHash\";s:54:\"20171203_desafiolatam_aee91e982c4137a56263171203224922\";s:4:\"Type\";i:0;s:5:\"Notes\";s:0:\"\";s:9:\"StorePath\";s:51:\"C:/Users/Yineska/Desktop/wordpress/wp-snapshots/tmp\";s:8:\"StoreURL\";s:35:\"http://localhost:8888/wp-snapshots/\";s:8:\"ScanFile\";N;s:7:\"Runtime\";N;s:7:\"ExeSize\";N;s:7:\"ZipSize\";N;s:6:\"Status\";N;s:6:\"WPUser\";N;s:7:\"Archive\";r:22;s:9:\"Installer\";O:13:\"DUP_Installer\":7:{s:4:\"File\";N;s:4:\"Size\";i:0;s:10:\"OptsDBHost\";s:0:\"\";s:10:\"OptsDBPort\";s:0:\"\";s:10:\"OptsDBName\";s:0:\"\";s:10:\"OptsDBUser\";s:0:\"\";s:10:\"\0*\0Package\";r:57;}s:8:\"Database\";O:12:\"DUP_Database\":13:{s:4:\"Type\";s:5:\"MySQL\";s:4:\"Size\";N;s:4:\"File\";N;s:4:\"Path\";N;s:12:\"FilterTables\";s:0:\"\";s:8:\"FilterOn\";i:0;s:4:\"Name\";N;s:10:\"Compatible\";s:0:\"\";s:8:\"Comments\";s:28:\"MySQL Community Server (GPL)\";s:10:\"\0*\0Package\";r:57;s:25:\"\0DUP_Database\0dbStorePath\";N;s:23:\"\0DUP_Database\0EOFMarker\";s:0:\"\";s:26:\"\0DUP_Database\0networkFlush\";b:0;}}s:29:\"\0DUP_Archive\0tmpFilterDirsAll\";a:0:{}s:24:\"\0DUP_Archive\0wpCorePaths\";a:6:{i:0;s:43:\"C:/Users/Yineska/Desktop/wordpress/wp-admin\";i:1;s:53:\"C:/Users/Yineska/Desktop/wordpress/wp-content/uploads\";i:2;s:55:\"C:/Users/Yineska/Desktop/wordpress/wp-content/languages\";i:3;s:53:\"C:/Users/Yineska/Desktop/wordpress/wp-content/plugins\";i:4;s:52:\"C:/Users/Yineska/Desktop/wordpress/wp-content/themes\";i:5;s:46:\"C:/Users/Yineska/Desktop/wordpress/wp-includes\";}}s:9:\"Installer\";r:79;s:8:\"Database\";r:87;}', 'yes'),
(640, 'theme_mods_eaterstop-lite', 'a:4:{i:0;b:0;s:18:\"nav_menu_locations\";a:2:{s:7:\"primary\";i:2;s:6:\"footer\";i:2;}s:18:\"custom_css_post_id\";i:-1;s:16:\"sidebars_widgets\";a:2:{s:4:\"time\";i:1512915433;s:4:\"data\";a:2:{s:19:\"wp_inactive_widgets\";a:7:{i:0;s:8:\"search-2\";i:1;s:14:\"recent-posts-2\";i:2;s:17:\"recent-comments-2\";i:3;s:10:\"archives-2\";i:4;s:12:\"categories-2\";i:5;s:6:\"meta-2\";i:6;s:6:\"text-2\";}s:9:\"sidebar-1\";a:1:{i:0;s:10:\"nav_menu-2\";}}}}', 'yes'),
(654, 'wp_ewwwio_media_optimize_batch_b', '', 'no'),
(748, 'category_children', 'a:0:{}', 'yes'),
(856, 'theme_mods_plum', 'a:4:{i:0;b:0;s:18:\"nav_menu_locations\";a:1:{s:7:\"primary\";i:2;}s:18:\"custom_css_post_id\";i:-1;s:16:\"sidebars_widgets\";a:2:{s:4:\"time\";i:1513013559;s:4:\"data\";a:5:{s:19:\"wp_inactive_widgets\";a:10:{i:0;s:8:\"search-2\";i:1;s:14:\"recent-posts-2\";i:2;s:17:\"recent-comments-2\";i:3;s:10:\"archives-2\";i:4;s:12:\"categories-2\";i:5;s:6:\"meta-2\";i:6;s:6:\"text-2\";i:7;s:10:\"nav_menu-2\";i:8;s:13:\"media_image-2\";i:9;s:8:\"search-3\";}s:9:\"sidebar-1\";a:0:{}s:8:\"footer-1\";a:0:{}s:8:\"footer-2\";a:0:{}s:8:\"footer-3\";a:0:{}}}}', 'yes'),
(857, 'widget_plum_rp', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(858, 'widget_plum_video_widget', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(860, '_transient_plum_categories', '0', 'yes'),
(864, 'theme_mods_foodhunt', 'a:4:{i:0;b:0;s:18:\"nav_menu_locations\";a:1:{s:11:\"primary_one\";i:2;}s:18:\"custom_css_post_id\";i:-1;s:16:\"sidebars_widgets\";a:2:{s:4:\"time\";i:1513032462;s:4:\"data\";a:8:{s:19:\"wp_inactive_widgets\";a:10:{i:0;s:8:\"search-2\";i:1;s:14:\"recent-posts-2\";i:2;s:17:\"recent-comments-2\";i:3;s:10:\"archives-2\";i:4;s:12:\"categories-2\";i:5;s:6:\"meta-2\";i:6;s:6:\"text-2\";i:7;s:10:\"nav_menu-2\";i:8;s:13:\"media_image-2\";i:9;s:8:\"search-3\";}s:22:\"foodhunt_right_sidebar\";a:0:{}s:21:\"foodhunt_left_sidebar\";a:0:{}s:25:\"foodhunt_business_sidebar\";a:0:{}s:24:\"foodhunt_footer_sidebar1\";a:0:{}s:24:\"foodhunt_footer_sidebar2\";a:0:{}s:24:\"foodhunt_footer_sidebar3\";a:0:{}s:24:\"foodhunt_footer_sidebar4\";a:0:{}}}}', 'yes'),
(865, 'widget_foodhunt_about_us_widget', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(866, 'widget_foodhunt_service_widget', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(867, 'widget_foodhunt_call_to_action_widget', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(868, 'widget_foodhunt_our_team_widget', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(869, 'widget_foodhunt_featured_posts_widget', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(870, 'widget_foodhunt_portfolio_widget', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(871, 'widget_foodhunt_contact_widget', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(873, 'foodhunt_admin_notice_welcome', '1', 'yes'),
(944, 'theme_mods_wp_boilerplate_child', 'a:4:{i:0;b:0;s:18:\"nav_menu_locations\";a:1:{s:11:\"header-menu\";i:2;}s:18:\"custom_css_post_id\";i:-1;s:16:\"sidebars_widgets\";a:2:{s:4:\"time\";i:1513108394;s:4:\"data\";a:3:{s:19:\"wp_inactive_widgets\";a:10:{i:0;s:8:\"search-2\";i:1;s:14:\"recent-posts-2\";i:2;s:17:\"recent-comments-2\";i:3;s:10:\"archives-2\";i:4;s:12:\"categories-2\";i:5;s:6:\"meta-2\";i:6;s:6:\"text-2\";i:7;s:10:\"nav_menu-2\";i:8;s:13:\"media_image-2\";i:9;s:8:\"search-3\";}s:14:\"sidebar_widget\";a:0:{}s:14:\"contact_widget\";a:0:{}}}}', 'yes'),
(1028, 'pdfemb_poweredby', '1', 'no'),
(1167, '_site_transient_timeout_browser_b876c8fd7fc402e60530b64622320f7a', '1516141391', 'no'),
(1168, '_site_transient_browser_b876c8fd7fc402e60530b64622320f7a', 'a:10:{s:4:\"name\";s:6:\"Chrome\";s:7:\"version\";s:13:\"63.0.3239.132\";s:8:\"platform\";s:7:\"Windows\";s:10:\"update_url\";s:29:\"https://www.google.com/chrome\";s:7:\"img_src\";s:43:\"http://s.w.org/images/browsers/chrome.png?1\";s:11:\"img_src_ssl\";s:44:\"https://s.w.org/images/browsers/chrome.png?1\";s:15:\"current_version\";s:2:\"18\";s:7:\"upgrade\";b:0;s:8:\"insecure\";b:0;s:6:\"mobile\";b:0;}', 'no'),
(1188, 'tadv_settings', 'a:6:{s:7:\"options\";s:15:\"menubar,advlist\";s:9:\"toolbar_1\";s:106:\"formatselect,bold,italic,blockquote,bullist,numlist,alignleft,aligncenter,alignright,link,unlink,undo,redo\";s:9:\"toolbar_2\";s:103:\"fontselect,fontsizeselect,outdent,indent,pastetext,removeformat,charmap,wp_more,forecolor,table,wp_help\";s:9:\"toolbar_3\";s:0:\"\";s:9:\"toolbar_4\";s:0:\"\";s:7:\"plugins\";s:104:\"anchor,code,insertdatetime,nonbreaking,print,searchreplace,table,visualblocks,visualchars,advlist,wptadv\";}', 'yes'),
(1189, 'tadv_admin_settings', 'a:1:{s:7:\"options\";a:0:{}}', 'yes'),
(1190, 'tadv_version', '4000', 'yes'),
(1228, '_site_transient_timeout_theme_roots', '1515796863', 'no'),
(1229, '_site_transient_theme_roots', 'a:11:{s:8:\"affluent\";s:7:\"/themes\";s:14:\"eaterstop-lite\";s:7:\"/themes\";s:8:\"foodhunt\";s:7:\"/themes\";s:12:\"landingpages\";s:7:\"/themes\";s:12:\"miprimertema\";s:7:\"/themes\";s:4:\"plum\";s:7:\"/themes\";s:13:\"twentyfifteen\";s:7:\"/themes\";s:15:\"twentyseventeen\";s:7:\"/themes\";s:13:\"twentysixteen\";s:7:\"/themes\";s:14:\"wp_boilerplate\";s:7:\"/themes\";s:20:\"wp_boilerplate_child\";s:7:\"/themes\";}', 'no'),
(1232, '_site_transient_update_core', 'O:8:\"stdClass\":4:{s:7:\"updates\";a:2:{i:0;O:8:\"stdClass\":10:{s:8:\"response\";s:7:\"upgrade\";s:8:\"download\";s:59:\"https://downloads.wordpress.org/release/wordpress-4.9.1.zip\";s:6:\"locale\";s:5:\"en_US\";s:8:\"packages\";O:8:\"stdClass\":5:{s:4:\"full\";s:59:\"https://downloads.wordpress.org/release/wordpress-4.9.1.zip\";s:10:\"no_content\";s:70:\"https://downloads.wordpress.org/release/wordpress-4.9.1-no-content.zip\";s:11:\"new_bundled\";s:71:\"https://downloads.wordpress.org/release/wordpress-4.9.1-new-bundled.zip\";s:7:\"partial\";s:69:\"https://downloads.wordpress.org/release/wordpress-4.9.1-partial-0.zip\";s:8:\"rollback\";b:0;}s:7:\"current\";s:5:\"4.9.1\";s:7:\"version\";s:5:\"4.9.1\";s:11:\"php_version\";s:5:\"5.2.4\";s:13:\"mysql_version\";s:3:\"5.0\";s:11:\"new_bundled\";s:3:\"4.7\";s:15:\"partial_version\";s:3:\"4.9\";}i:1;O:8:\"stdClass\":11:{s:8:\"response\";s:10:\"autoupdate\";s:8:\"download\";s:59:\"https://downloads.wordpress.org/release/wordpress-4.9.1.zip\";s:6:\"locale\";s:5:\"en_US\";s:8:\"packages\";O:8:\"stdClass\":5:{s:4:\"full\";s:59:\"https://downloads.wordpress.org/release/wordpress-4.9.1.zip\";s:10:\"no_content\";s:70:\"https://downloads.wordpress.org/release/wordpress-4.9.1-no-content.zip\";s:11:\"new_bundled\";s:71:\"https://downloads.wordpress.org/release/wordpress-4.9.1-new-bundled.zip\";s:7:\"partial\";s:69:\"https://downloads.wordpress.org/release/wordpress-4.9.1-partial-0.zip\";s:8:\"rollback\";s:70:\"https://downloads.wordpress.org/release/wordpress-4.9.1-rollback-0.zip\";}s:7:\"current\";s:5:\"4.9.1\";s:7:\"version\";s:5:\"4.9.1\";s:11:\"php_version\";s:5:\"5.2.4\";s:13:\"mysql_version\";s:3:\"5.0\";s:11:\"new_bundled\";s:3:\"4.7\";s:15:\"partial_version\";s:3:\"4.9\";s:9:\"new_files\";s:0:\"\";}}s:12:\"last_checked\";i:1515795067;s:15:\"version_checked\";s:3:\"4.9\";s:12:\"translations\";a:1:{i:0;a:7:{s:4:\"type\";s:4:\"core\";s:4:\"slug\";s:7:\"default\";s:8:\"language\";s:5:\"es_ES\";s:7:\"version\";s:3:\"4.9\";s:7:\"updated\";s:19:\"2017-11-28 20:17:28\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.9/es_ES.zip\";s:10:\"autoupdate\";b:1;}}}', 'no'),
(1233, '_site_transient_update_themes', 'O:8:\"stdClass\":4:{s:12:\"last_checked\";i:1515795072;s:7:\"checked\";a:11:{s:8:\"affluent\";s:5:\"1.0.5\";s:14:\"eaterstop-lite\";s:3:\"1.5\";s:8:\"foodhunt\";s:5:\"1.0.6\";s:12:\"landingpages\";s:3:\"1.0\";s:12:\"miprimertema\";s:3:\"1.0\";s:4:\"plum\";s:5:\"1.3.3\";s:13:\"twentyfifteen\";s:3:\"1.9\";s:15:\"twentyseventeen\";s:3:\"1.4\";s:13:\"twentysixteen\";s:3:\"1.4\";s:14:\"wp_boilerplate\";s:5:\"1.0.2\";s:20:\"wp_boilerplate_child\";s:5:\"1.0.2\";}s:8:\"response\";a:1:{s:4:\"plum\";a:4:{s:5:\"theme\";s:4:\"plum\";s:11:\"new_version\";s:5:\"1.3.5\";s:3:\"url\";s:34:\"https://wordpress.org/themes/plum/\";s:7:\"package\";s:52:\"https://downloads.wordpress.org/theme/plum.1.3.5.zip\";}}s:12:\"translations\";a:4:{i:0;a:7:{s:4:\"type\";s:5:\"theme\";s:4:\"slug\";s:13:\"twentyfifteen\";s:8:\"language\";s:5:\"es_ES\";s:7:\"version\";s:3:\"1.9\";s:7:\"updated\";s:19:\"2017-11-16 16:17:43\";s:7:\"package\";s:77:\"https://downloads.wordpress.org/translation/theme/twentyfifteen/1.9/es_ES.zip\";s:10:\"autoupdate\";b:1;}i:1;a:7:{s:4:\"type\";s:5:\"theme\";s:4:\"slug\";s:13:\"twentyfifteen\";s:8:\"language\";s:5:\"es_VE\";s:7:\"version\";s:3:\"1.9\";s:7:\"updated\";s:19:\"2015-10-29 16:42:00\";s:7:\"package\";s:77:\"https://downloads.wordpress.org/translation/theme/twentyfifteen/1.9/es_VE.zip\";s:10:\"autoupdate\";b:1;}i:2;a:7:{s:4:\"type\";s:5:\"theme\";s:4:\"slug\";s:15:\"twentyseventeen\";s:8:\"language\";s:5:\"es_ES\";s:7:\"version\";s:3:\"1.4\";s:7:\"updated\";s:19:\"2017-11-30 21:43:28\";s:7:\"package\";s:79:\"https://downloads.wordpress.org/translation/theme/twentyseventeen/1.4/es_ES.zip\";s:10:\"autoupdate\";b:1;}i:3;a:7:{s:4:\"type\";s:5:\"theme\";s:4:\"slug\";s:13:\"twentysixteen\";s:8:\"language\";s:5:\"es_ES\";s:7:\"version\";s:3:\"1.4\";s:7:\"updated\";s:19:\"2017-01-29 00:58:00\";s:7:\"package\";s:77:\"https://downloads.wordpress.org/translation/theme/twentysixteen/1.4/es_ES.zip\";s:10:\"autoupdate\";b:1;}}}', 'no');
INSERT INTO `dl_options` (`option_id`, `option_name`, `option_value`, `autoload`) VALUES
(1234, '_site_transient_update_plugins', 'O:8:\"stdClass\":4:{s:12:\"last_checked\";i:1515795070;s:8:\"response\";a:4:{s:19:\"akismet/akismet.php\";O:8:\"stdClass\":11:{s:2:\"id\";s:21:\"w.org/plugins/akismet\";s:4:\"slug\";s:7:\"akismet\";s:6:\"plugin\";s:19:\"akismet/akismet.php\";s:11:\"new_version\";s:5:\"4.0.2\";s:3:\"url\";s:38:\"https://wordpress.org/plugins/akismet/\";s:7:\"package\";s:56:\"https://downloads.wordpress.org/plugin/akismet.4.0.2.zip\";s:5:\"icons\";a:3:{s:2:\"1x\";s:59:\"https://ps.w.org/akismet/assets/icon-128x128.png?rev=969272\";s:2:\"2x\";s:59:\"https://ps.w.org/akismet/assets/icon-256x256.png?rev=969272\";s:7:\"default\";s:59:\"https://ps.w.org/akismet/assets/icon-256x256.png?rev=969272\";}s:7:\"banners\";a:2:{s:2:\"1x\";s:61:\"https://ps.w.org/akismet/assets/banner-772x250.jpg?rev=479904\";s:7:\"default\";s:61:\"https://ps.w.org/akismet/assets/banner-772x250.jpg?rev=479904\";}s:11:\"banners_rtl\";a:0:{}s:6:\"tested\";s:5:\"4.9.1\";s:13:\"compatibility\";O:8:\"stdClass\":0:{}}s:36:\"contact-form-7/wp-contact-form-7.php\";O:8:\"stdClass\":11:{s:2:\"id\";s:28:\"w.org/plugins/contact-form-7\";s:4:\"slug\";s:14:\"contact-form-7\";s:6:\"plugin\";s:36:\"contact-form-7/wp-contact-form-7.php\";s:11:\"new_version\";s:5:\"4.9.2\";s:3:\"url\";s:45:\"https://wordpress.org/plugins/contact-form-7/\";s:7:\"package\";s:63:\"https://downloads.wordpress.org/plugin/contact-form-7.4.9.2.zip\";s:5:\"icons\";a:3:{s:2:\"1x\";s:66:\"https://ps.w.org/contact-form-7/assets/icon-128x128.png?rev=984007\";s:2:\"2x\";s:66:\"https://ps.w.org/contact-form-7/assets/icon-256x256.png?rev=984007\";s:7:\"default\";s:66:\"https://ps.w.org/contact-form-7/assets/icon-256x256.png?rev=984007\";}s:7:\"banners\";a:3:{s:2:\"2x\";s:69:\"https://ps.w.org/contact-form-7/assets/banner-1544x500.png?rev=860901\";s:2:\"1x\";s:68:\"https://ps.w.org/contact-form-7/assets/banner-772x250.png?rev=880427\";s:7:\"default\";s:69:\"https://ps.w.org/contact-form-7/assets/banner-1544x500.png?rev=860901\";}s:11:\"banners_rtl\";a:0:{}s:6:\"tested\";s:5:\"4.9.1\";s:13:\"compatibility\";O:8:\"stdClass\":0:{}}s:25:\"duplicator/duplicator.php\";O:8:\"stdClass\":11:{s:2:\"id\";s:24:\"w.org/plugins/duplicator\";s:4:\"slug\";s:10:\"duplicator\";s:6:\"plugin\";s:25:\"duplicator/duplicator.php\";s:11:\"new_version\";s:6:\"1.2.32\";s:3:\"url\";s:41:\"https://wordpress.org/plugins/duplicator/\";s:7:\"package\";s:60:\"https://downloads.wordpress.org/plugin/duplicator.1.2.32.zip\";s:5:\"icons\";a:3:{s:2:\"1x\";s:63:\"https://ps.w.org/duplicator/assets/icon-128x128.png?rev=1298463\";s:2:\"2x\";s:63:\"https://ps.w.org/duplicator/assets/icon-256x256.png?rev=1298463\";s:7:\"default\";s:63:\"https://ps.w.org/duplicator/assets/icon-256x256.png?rev=1298463\";}s:7:\"banners\";a:2:{s:2:\"1x\";s:65:\"https://ps.w.org/duplicator/assets/banner-772x250.png?rev=1645055\";s:7:\"default\";s:65:\"https://ps.w.org/duplicator/assets/banner-772x250.png?rev=1645055\";}s:11:\"banners_rtl\";a:0:{}s:6:\"tested\";s:5:\"4.9.1\";s:13:\"compatibility\";O:8:\"stdClass\":0:{}}s:45:\"ewww-image-optimizer/ewww-image-optimizer.php\";O:8:\"stdClass\":11:{s:2:\"id\";s:34:\"w.org/plugins/ewww-image-optimizer\";s:4:\"slug\";s:20:\"ewww-image-optimizer\";s:6:\"plugin\";s:45:\"ewww-image-optimizer/ewww-image-optimizer.php\";s:11:\"new_version\";s:5:\"4.0.6\";s:3:\"url\";s:51:\"https://wordpress.org/plugins/ewww-image-optimizer/\";s:7:\"package\";s:69:\"https://downloads.wordpress.org/plugin/ewww-image-optimizer.4.0.6.zip\";s:5:\"icons\";a:3:{s:2:\"1x\";s:73:\"https://ps.w.org/ewww-image-optimizer/assets/icon-128x128.png?rev=1582276\";s:2:\"2x\";s:73:\"https://ps.w.org/ewww-image-optimizer/assets/icon-256x256.png?rev=1582276\";s:7:\"default\";s:73:\"https://ps.w.org/ewww-image-optimizer/assets/icon-256x256.png?rev=1582276\";}s:7:\"banners\";a:3:{s:2:\"2x\";s:76:\"https://ps.w.org/ewww-image-optimizer/assets/banner-1544x500.jpg?rev=1582276\";s:2:\"1x\";s:75:\"https://ps.w.org/ewww-image-optimizer/assets/banner-772x250.jpg?rev=1582276\";s:7:\"default\";s:76:\"https://ps.w.org/ewww-image-optimizer/assets/banner-1544x500.jpg?rev=1582276\";}s:11:\"banners_rtl\";a:0:{}s:6:\"tested\";s:5:\"4.9.1\";s:13:\"compatibility\";O:8:\"stdClass\":0:{}}}s:12:\"translations\";a:8:{i:0;a:7:{s:4:\"type\";s:6:\"plugin\";s:4:\"slug\";s:7:\"akismet\";s:8:\"language\";s:5:\"es_ES\";s:7:\"version\";s:5:\"4.0.1\";s:7:\"updated\";s:19:\"2017-09-19 18:01:44\";s:7:\"package\";s:74:\"https://downloads.wordpress.org/translation/plugin/akismet/4.0.1/es_ES.zip\";s:10:\"autoupdate\";b:1;}i:1;a:7:{s:4:\"type\";s:6:\"plugin\";s:4:\"slug\";s:7:\"akismet\";s:8:\"language\";s:5:\"es_VE\";s:7:\"version\";s:3:\"3.2\";s:7:\"updated\";s:19:\"2016-12-02 15:28:12\";s:7:\"package\";s:72:\"https://downloads.wordpress.org/translation/plugin/akismet/3.2/es_VE.zip\";s:10:\"autoupdate\";b:1;}i:2;a:7:{s:4:\"type\";s:6:\"plugin\";s:4:\"slug\";s:14:\"contact-form-7\";s:8:\"language\";s:5:\"es_ES\";s:7:\"version\";s:5:\"4.9.1\";s:7:\"updated\";s:19:\"2017-10-31 09:59:17\";s:7:\"package\";s:81:\"https://downloads.wordpress.org/translation/plugin/contact-form-7/4.9.1/es_ES.zip\";s:10:\"autoupdate\";b:1;}i:3;a:7:{s:4:\"type\";s:6:\"plugin\";s:4:\"slug\";s:14:\"contact-form-7\";s:8:\"language\";s:5:\"es_VE\";s:7:\"version\";s:5:\"4.6.1\";s:7:\"updated\";s:19:\"2016-09-27 15:02:11\";s:7:\"package\";s:81:\"https://downloads.wordpress.org/translation/plugin/contact-form-7/4.6.1/es_VE.zip\";s:10:\"autoupdate\";b:1;}i:4;a:7:{s:4:\"type\";s:6:\"plugin\";s:4:\"slug\";s:10:\"duplicator\";s:8:\"language\";s:5:\"es_ES\";s:7:\"version\";s:6:\"1.2.30\";s:7:\"updated\";s:19:\"2017-10-03 19:05:08\";s:7:\"package\";s:78:\"https://downloads.wordpress.org/translation/plugin/duplicator/1.2.30/es_ES.zip\";s:10:\"autoupdate\";b:1;}i:5;a:7:{s:4:\"type\";s:6:\"plugin\";s:4:\"slug\";s:20:\"ewww-image-optimizer\";s:8:\"language\";s:5:\"es_ES\";s:7:\"version\";s:5:\"4.0.3\";s:7:\"updated\";s:19:\"2017-11-29 20:53:25\";s:7:\"package\";s:87:\"https://downloads.wordpress.org/translation/plugin/ewww-image-optimizer/4.0.3/es_ES.zip\";s:10:\"autoupdate\";b:1;}i:6;a:7:{s:4:\"type\";s:6:\"plugin\";s:4:\"slug\";s:11:\"hello-dolly\";s:8:\"language\";s:5:\"es_ES\";s:7:\"version\";s:3:\"1.6\";s:7:\"updated\";s:19:\"2017-09-22 18:05:32\";s:7:\"package\";s:76:\"https://downloads.wordpress.org/translation/plugin/hello-dolly/1.6/es_ES.zip\";s:10:\"autoupdate\";b:1;}i:7;a:7:{s:4:\"type\";s:6:\"plugin\";s:4:\"slug\";s:16:\"tinymce-advanced\";s:8:\"language\";s:5:\"es_ES\";s:7:\"version\";s:5:\"4.6.7\";s:7:\"updated\";s:19:\"2017-05-02 07:10:25\";s:7:\"package\";s:83:\"https://downloads.wordpress.org/translation/plugin/tinymce-advanced/4.6.7/es_ES.zip\";s:10:\"autoupdate\";b:1;}}s:9:\"no_update\";a:5:{s:30:\"advanced-custom-fields/acf.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:36:\"w.org/plugins/advanced-custom-fields\";s:4:\"slug\";s:22:\"advanced-custom-fields\";s:6:\"plugin\";s:30:\"advanced-custom-fields/acf.php\";s:11:\"new_version\";s:6:\"4.4.12\";s:3:\"url\";s:53:\"https://wordpress.org/plugins/advanced-custom-fields/\";s:7:\"package\";s:72:\"https://downloads.wordpress.org/plugin/advanced-custom-fields.4.4.12.zip\";s:5:\"icons\";a:3:{s:2:\"1x\";s:75:\"https://ps.w.org/advanced-custom-fields/assets/icon-128x128.png?rev=1082746\";s:2:\"2x\";s:75:\"https://ps.w.org/advanced-custom-fields/assets/icon-256x256.png?rev=1082746\";s:7:\"default\";s:75:\"https://ps.w.org/advanced-custom-fields/assets/icon-256x256.png?rev=1082746\";}s:7:\"banners\";a:3:{s:2:\"2x\";s:78:\"https://ps.w.org/advanced-custom-fields/assets/banner-1544x500.jpg?rev=1729099\";s:2:\"1x\";s:77:\"https://ps.w.org/advanced-custom-fields/assets/banner-772x250.jpg?rev=1729102\";s:7:\"default\";s:78:\"https://ps.w.org/advanced-custom-fields/assets/banner-1544x500.jpg?rev=1729099\";}s:11:\"banners_rtl\";a:0:{}}s:42:\"contact-form-cfdb7/contact-form-cfdb-7.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:32:\"w.org/plugins/contact-form-cfdb7\";s:4:\"slug\";s:18:\"contact-form-cfdb7\";s:6:\"plugin\";s:42:\"contact-form-cfdb7/contact-form-cfdb-7.php\";s:11:\"new_version\";s:5:\"1.1.6\";s:3:\"url\";s:49:\"https://wordpress.org/plugins/contact-form-cfdb7/\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/plugin/contact-form-cfdb7.zip\";s:5:\"icons\";a:3:{s:2:\"1x\";s:71:\"https://ps.w.org/contact-form-cfdb7/assets/icon-128x128.png?rev=1619878\";s:2:\"2x\";s:71:\"https://ps.w.org/contact-form-cfdb7/assets/icon-256x256.png?rev=1619878\";s:7:\"default\";s:71:\"https://ps.w.org/contact-form-cfdb7/assets/icon-256x256.png?rev=1619878\";}s:7:\"banners\";a:2:{s:2:\"1x\";s:73:\"https://ps.w.org/contact-form-cfdb7/assets/banner-772x250.png?rev=1619902\";s:7:\"default\";s:73:\"https://ps.w.org/contact-form-cfdb7/assets/banner-772x250.png?rev=1619902\";}s:11:\"banners_rtl\";a:0:{}}s:9:\"hello.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:25:\"w.org/plugins/hello-dolly\";s:4:\"slug\";s:11:\"hello-dolly\";s:6:\"plugin\";s:9:\"hello.php\";s:11:\"new_version\";s:3:\"1.6\";s:3:\"url\";s:42:\"https://wordpress.org/plugins/hello-dolly/\";s:7:\"package\";s:58:\"https://downloads.wordpress.org/plugin/hello-dolly.1.6.zip\";s:5:\"icons\";a:3:{s:2:\"1x\";s:63:\"https://ps.w.org/hello-dolly/assets/icon-128x128.jpg?rev=969907\";s:2:\"2x\";s:63:\"https://ps.w.org/hello-dolly/assets/icon-256x256.jpg?rev=969907\";s:7:\"default\";s:63:\"https://ps.w.org/hello-dolly/assets/icon-256x256.jpg?rev=969907\";}s:7:\"banners\";a:2:{s:2:\"1x\";s:65:\"https://ps.w.org/hello-dolly/assets/banner-772x250.png?rev=478342\";s:7:\"default\";s:65:\"https://ps.w.org/hello-dolly/assets/banner-772x250.png?rev=478342\";}s:11:\"banners_rtl\";a:0:{}}s:29:\"pdf-embedder/pdf_embedder.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:26:\"w.org/plugins/pdf-embedder\";s:4:\"slug\";s:12:\"pdf-embedder\";s:6:\"plugin\";s:29:\"pdf-embedder/pdf_embedder.php\";s:11:\"new_version\";s:5:\"3.1.8\";s:3:\"url\";s:43:\"https://wordpress.org/plugins/pdf-embedder/\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/plugin/pdf-embedder.3.1.8.zip\";s:5:\"icons\";a:3:{s:2:\"1x\";s:65:\"https://ps.w.org/pdf-embedder/assets/icon-128x128.png?rev=1072588\";s:2:\"2x\";s:65:\"https://ps.w.org/pdf-embedder/assets/icon-256x256.png?rev=1072588\";s:7:\"default\";s:65:\"https://ps.w.org/pdf-embedder/assets/icon-256x256.png?rev=1072588\";}s:7:\"banners\";a:3:{s:2:\"2x\";s:68:\"https://ps.w.org/pdf-embedder/assets/banner-1544x500.png?rev=1629344\";s:2:\"1x\";s:67:\"https://ps.w.org/pdf-embedder/assets/banner-772x250.png?rev=1629344\";s:7:\"default\";s:68:\"https://ps.w.org/pdf-embedder/assets/banner-1544x500.png?rev=1629344\";}s:11:\"banners_rtl\";a:0:{}}s:37:\"tinymce-advanced/tinymce-advanced.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:30:\"w.org/plugins/tinymce-advanced\";s:4:\"slug\";s:16:\"tinymce-advanced\";s:6:\"plugin\";s:37:\"tinymce-advanced/tinymce-advanced.php\";s:11:\"new_version\";s:5:\"4.6.7\";s:3:\"url\";s:47:\"https://wordpress.org/plugins/tinymce-advanced/\";s:7:\"package\";s:65:\"https://downloads.wordpress.org/plugin/tinymce-advanced.4.6.7.zip\";s:5:\"icons\";a:3:{s:2:\"1x\";s:68:\"https://ps.w.org/tinymce-advanced/assets/icon-128x128.png?rev=971511\";s:2:\"2x\";s:68:\"https://ps.w.org/tinymce-advanced/assets/icon-256x256.png?rev=971511\";s:7:\"default\";s:68:\"https://ps.w.org/tinymce-advanced/assets/icon-256x256.png?rev=971511\";}s:7:\"banners\";a:2:{s:2:\"1x\";s:70:\"https://ps.w.org/tinymce-advanced/assets/banner-772x250.png?rev=894078\";s:7:\"default\";s:70:\"https://ps.w.org/tinymce-advanced/assets/banner-772x250.png?rev=894078\";}s:11:\"banners_rtl\";a:0:{}}}}', 'no');

-- --------------------------------------------------------

--
-- Table structure for table `dl_phone2app_form`
--

CREATE TABLE `dl_phone2app_form` (
  `id` varchar(11) NOT NULL,
  `link` varchar(250) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `dl_phone2app_user`
--

CREATE TABLE `dl_phone2app_user` (
  `username` varchar(200) NOT NULL DEFAULT '',
  `password` varchar(200) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `dl_postmeta`
--

CREATE TABLE `dl_postmeta` (
  `meta_id` bigint(20) UNSIGNED NOT NULL,
  `post_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Dumping data for table `dl_postmeta`
--

INSERT INTO `dl_postmeta` (`meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(89, 36, '_form', '[select menu-558][text* your-name] </label>\n\n<label> Your Email (required)\n    [email* your-email] </label>\n\n<label> Subject\n    [text your-subject] </label>\n\n<label> Your Message\n    [textarea your-message] </label>\n<label>[file* file-409 filetypes:pdf|doc class:field]<label> Your Name (required)</label>\n[submit \"Send\"]'),
(90, 36, '_mail', 'a:9:{s:6:\"active\";b:1;s:7:\"subject\";s:30:\"Desafio Latam \"[your-subject]\"\";s:6:\"sender\";s:44:\"[your-name] <jose.martinez.mayora@gmail.com>\";s:9:\"recipient\";s:30:\"jose.martinez.mayora@gmail.com\";s:4:\"body\";s:173:\"From: [your-name] <[your-email]>\nSubject: [your-subject]\n\nMessage Body:\n[your-message]\n\n-- \nThis e-mail was sent from a contact form on Desafio Latam (http://localhost:8888)\";s:18:\"additional_headers\";s:22:\"Reply-To: [your-email]\";s:11:\"attachments\";s:0:\"\";s:8:\"use_html\";b:0;s:13:\"exclude_blank\";b:0;}'),
(91, 36, '_mail_2', 'a:9:{s:6:\"active\";b:0;s:7:\"subject\";s:30:\"Desafio Latam \"[your-subject]\"\";s:6:\"sender\";s:46:\"Desafio Latam <jose.martinez.mayora@gmail.com>\";s:9:\"recipient\";s:12:\"[your-email]\";s:4:\"body\";s:115:\"Message Body:\n[your-message]\n\n-- \nThis e-mail was sent from a contact form on Desafio Latam (http://localhost:8888)\";s:18:\"additional_headers\";s:40:\"Reply-To: jose.martinez.mayora@gmail.com\";s:11:\"attachments\";s:0:\"\";s:8:\"use_html\";b:0;s:13:\"exclude_blank\";b:0;}'),
(92, 36, '_messages', 'a:23:{s:12:\"mail_sent_ok\";s:45:\"Thank you for your message. It has been sent.\";s:12:\"mail_sent_ng\";s:71:\"There was an error trying to send your message. Please try again later.\";s:16:\"validation_error\";s:61:\"One or more fields have an error. Please check and try again.\";s:4:\"spam\";s:71:\"There was an error trying to send your message. Please try again later.\";s:12:\"accept_terms\";s:69:\"You must accept the terms and conditions before sending your message.\";s:16:\"invalid_required\";s:22:\"The field is required.\";s:16:\"invalid_too_long\";s:22:\"The field is too long.\";s:17:\"invalid_too_short\";s:23:\"The field is too short.\";s:12:\"invalid_date\";s:29:\"The date format is incorrect.\";s:14:\"date_too_early\";s:44:\"The date is before the earliest one allowed.\";s:13:\"date_too_late\";s:41:\"The date is after the latest one allowed.\";s:13:\"upload_failed\";s:46:\"There was an unknown error uploading the file.\";s:24:\"upload_file_type_invalid\";s:49:\"You are not allowed to upload files of this type.\";s:21:\"upload_file_too_large\";s:20:\"The file is too big.\";s:23:\"upload_failed_php_error\";s:38:\"There was an error uploading the file.\";s:14:\"invalid_number\";s:29:\"The number format is invalid.\";s:16:\"number_too_small\";s:47:\"The number is smaller than the minimum allowed.\";s:16:\"number_too_large\";s:46:\"The number is larger than the maximum allowed.\";s:23:\"quiz_answer_not_correct\";s:36:\"The answer to the quiz is incorrect.\";s:17:\"captcha_not_match\";s:31:\"Your entered code is incorrect.\";s:13:\"invalid_email\";s:38:\"The e-mail address entered is invalid.\";s:11:\"invalid_url\";s:19:\"The URL is invalid.\";s:11:\"invalid_tel\";s:32:\"The telephone number is invalid.\";}'),
(93, 36, '_additional_settings', ''),
(94, 36, '_locale', 'es_VE'),
(399, 110, '_edit_last', '1'),
(400, 110, '_edit_lock', '1513012823:1'),
(401, 110, 'marca', 'null'),
(402, 110, '_marca', 'field_5a1b643ebe78f'),
(403, 110, 'Imagenes', ''),
(404, 110, '_Imagenes', 'field_5a20803df8995'),
(405, 112, '_edit_last', '1'),
(406, 112, '_edit_lock', '1513012813:1'),
(407, 112, 'marca', 'null'),
(408, 112, '_marca', 'field_5a1b643ebe78f'),
(409, 112, 'Imagenes', ''),
(410, 112, '_Imagenes', 'field_5a20803df8995'),
(411, 113, '_edit_last', '1'),
(412, 113, '_edit_lock', '1513012802:1'),
(413, 113, 'marca', 'null'),
(414, 113, '_marca', 'field_5a1b643ebe78f'),
(415, 113, 'Imagenes', ''),
(416, 113, '_Imagenes', 'field_5a20803df8995'),
(420, 114, '_edit_last', '1'),
(421, 114, '_edit_lock', '1513780318:1'),
(422, 116, '_menu_item_type', 'post_type'),
(423, 116, '_menu_item_menu_item_parent', '0'),
(424, 116, '_menu_item_object_id', '114'),
(425, 116, '_menu_item_object', 'page'),
(426, 116, '_menu_item_target', ''),
(427, 116, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(428, 116, '_menu_item_xfn', ''),
(429, 116, '_menu_item_url', ''),
(443, 122, '_edit_last', '1'),
(444, 122, '_edit_lock', '1513030629:1'),
(445, 124, '_menu_item_type', 'post_type'),
(446, 124, '_menu_item_menu_item_parent', '0'),
(447, 124, '_menu_item_object_id', '122'),
(448, 124, '_menu_item_object', 'page'),
(449, 124, '_menu_item_target', ''),
(450, 124, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(451, 124, '_menu_item_xfn', ''),
(452, 124, '_menu_item_url', ''),
(453, 124, '_menu_item_orphaned', '1513030777'),
(454, 125, '_edit_last', '1'),
(455, 125, '_edit_lock', '1513791507:1'),
(456, 127, '_menu_item_type', 'post_type'),
(457, 127, '_menu_item_menu_item_parent', '0'),
(458, 127, '_menu_item_object_id', '125'),
(459, 127, '_menu_item_object', 'page'),
(460, 127, '_menu_item_target', ''),
(461, 127, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(462, 127, '_menu_item_xfn', ''),
(463, 127, '_menu_item_url', ''),
(465, 128, '_menu_item_type', 'post_type'),
(466, 128, '_menu_item_menu_item_parent', '0'),
(467, 128, '_menu_item_object_id', '122'),
(468, 128, '_menu_item_object', 'page'),
(469, 128, '_menu_item_target', ''),
(470, 128, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(471, 128, '_menu_item_xfn', ''),
(472, 128, '_menu_item_url', ''),
(473, 129, '_edit_last', '1'),
(474, 129, '_edit_lock', '1513791658:1'),
(480, 132, '_edit_last', '1'),
(481, 132, '_edit_lock', '1513791664:1'),
(487, 135, '_edit_last', '1'),
(488, 135, '_edit_lock', '1513791669:1'),
(494, 138, '_edit_last', '1'),
(495, 138, '_edit_lock', '1513085324:1'),
(499, 140, '_edit_last', '1'),
(500, 140, '_edit_lock', '1513791533:1'),
(514, 145, '_edit_last', '1'),
(515, 145, '_edit_lock', '1513085757:1'),
(516, 147, '_menu_item_type', 'post_type'),
(517, 147, '_menu_item_menu_item_parent', '0'),
(518, 147, '_menu_item_object_id', '145'),
(519, 147, '_menu_item_object', 'page'),
(520, 147, '_menu_item_target', ''),
(521, 147, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(522, 147, '_menu_item_xfn', ''),
(523, 147, '_menu_item_url', ''),
(524, 147, '_menu_item_orphaned', '1513085904'),
(525, 148, '_menu_item_type', 'post_type'),
(526, 148, '_menu_item_menu_item_parent', '0'),
(527, 148, '_menu_item_object_id', '145'),
(528, 148, '_menu_item_object', 'page'),
(529, 148, '_menu_item_target', ''),
(530, 148, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(531, 148, '_menu_item_xfn', ''),
(532, 148, '_menu_item_url', ''),
(537, 149, '_edit_last', '1'),
(541, 149, 'position', 'side'),
(542, 149, 'layout', 'no_box'),
(543, 149, 'hide_on_screen', ''),
(544, 149, '_edit_lock', '1515548710:1'),
(550, 149, 'field_5a2feffe97fe4', 'a:15:{s:3:\"key\";s:19:\"field_5a2feffe97fe4\";s:5:\"label\";s:7:\"Precios\";s:4:\"name\";s:7:\"precios\";s:4:\"type\";s:6:\"number\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";s:1:\"1\";s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:3:\"min\";s:0:\"\";s:3:\"max\";s:0:\"\";s:4:\"step\";s:1:\"0\";s:17:\"conditional_logic\";a:3:{s:6:\"status\";s:1:\"0\";s:5:\"rules\";a:1:{i:0;a:3:{s:5:\"field\";s:4:\"null\";s:8:\"operator\";s:2:\"==\";s:5:\"value\";s:0:\"\";}}s:8:\"allorany\";s:3:\"all\";}s:8:\"order_no\";i:0;}'),
(559, 153, '_edit_last', '1'),
(560, 153, '_edit_lock', '1513098602:1'),
(561, 153, 'tipo', 's/salsa: Pizza Blanca'),
(562, 153, '_tipo', 'field_5a2fe92395921'),
(563, 153, 'imagen', '118'),
(564, 153, '_imagen', 'field_5a2feef1be703'),
(565, 153, '_', 'field_5a2ff174e224d'),
(566, 153, 'descripcion', 'muy bueno:Muy bueno.'),
(567, 153, '_descripcion', 'field_5a2ff06ce224c'),
(569, 154, '_edit_last', '1'),
(570, 154, '_edit_lock', '1514462278:1'),
(571, 154, 'tipo', 's/salsa: Pizza Blanca'),
(572, 154, '_tipo', 'field_5a2fe92395921'),
(573, 154, 'imagen', '118'),
(574, 154, '_imagen', 'field_5a2feef1be703'),
(575, 154, '_', 'field_5a2ff174e224d'),
(576, 154, 'descripcion', 'muy bueno:Muy bueno.'),
(577, 154, '_descripcion', 'field_5a2ff06ce224c'),
(579, 113, '_wp_trash_meta_status', 'publish'),
(580, 113, '_wp_trash_meta_time', '1513774984'),
(581, 113, '_wp_desired_post_slug', 'tercera-entrada-del-blog'),
(582, 112, '_wp_trash_meta_status', 'publish'),
(583, 112, '_wp_trash_meta_time', '1513774988'),
(584, 112, '_wp_desired_post_slug', 'segunda-entrada-de-blog'),
(585, 110, '_wp_trash_meta_status', 'publish'),
(586, 110, '_wp_trash_meta_time', '1513774990'),
(587, 110, '_wp_desired_post_slug', 'esta-es-la-primera-noticia-del-blog'),
(588, 122, '_wp_trash_meta_status', 'publish'),
(589, 122, '_wp_trash_meta_time', '1513780430'),
(590, 122, '_wp_desired_post_slug', 'nosotros'),
(591, 140, '_wp_trash_meta_status', 'publish'),
(592, 140, '_wp_trash_meta_time', '1513791826'),
(593, 140, '_wp_desired_post_slug', 'entrada-5'),
(594, 138, '_wp_trash_meta_status', 'publish'),
(595, 138, '_wp_trash_meta_time', '1513791826'),
(596, 138, '_wp_desired_post_slug', 'entrada-4'),
(597, 135, '_wp_trash_meta_status', 'publish'),
(598, 135, '_wp_trash_meta_time', '1513791826'),
(599, 135, '_wp_desired_post_slug', 'entrada-3'),
(600, 132, '_wp_trash_meta_status', 'publish'),
(601, 132, '_wp_trash_meta_time', '1513791826'),
(602, 132, '_wp_desired_post_slug', 'entrada-2'),
(603, 129, '_wp_trash_meta_status', 'publish'),
(604, 129, '_wp_trash_meta_time', '1513791826'),
(605, 129, '_wp_desired_post_slug', 'entrada-1'),
(606, 156, '_edit_last', '1'),
(607, 156, '_edit_lock', '1513895185:1'),
(608, 157, '_wp_attached_file', '2017/12/camaron.jpeg'),
(609, 157, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:1280;s:6:\"height\";i:960;s:4:\"file\";s:20:\"2017/12/camaron.jpeg\";s:5:\"sizes\";a:6:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:20:\"camaron-150x150.jpeg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:20:\"camaron-300x225.jpeg\";s:5:\"width\";i:300;s:6:\"height\";i:225;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:20:\"camaron-768x576.jpeg\";s:5:\"width\";i:768;s:6:\"height\";i:576;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:21:\"camaron-1024x768.jpeg\";s:5:\"width\";i:1024;s:6:\"height\";i:768;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:4:\"Size\";a:4:{s:4:\"file\";s:20:\"camaron-400x400.jpeg\";s:5:\"width\";i:400;s:6:\"height\";i:400;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"custom_logo\";a:4:{s:4:\"file\";s:20:\"camaron-800x600.jpeg\";s:5:\"width\";i:800;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(610, 158, '_wp_attached_file', '2017/12/g1.png'),
(611, 158, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:600;s:6:\"height\";i:450;s:4:\"file\";s:14:\"2017/12/g1.png\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:14:\"g1-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:6:\"medium\";a:4:{s:4:\"file\";s:14:\"g1-300x225.png\";s:5:\"width\";i:300;s:6:\"height\";i:225;s:9:\"mime-type\";s:9:\"image/png\";}s:4:\"Size\";a:4:{s:4:\"file\";s:14:\"g1-400x400.png\";s:5:\"width\";i:400;s:6:\"height\";i:400;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(612, 159, '_wp_attached_file', '2017/12/Pizza-1.jpg'),
(613, 159, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:2322;s:6:\"height\";i:1382;s:4:\"file\";s:19:\"2017/12/Pizza-1.jpg\";s:5:\"sizes\";a:6:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:19:\"Pizza-1-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:19:\"Pizza-1-300x179.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:179;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:19:\"Pizza-1-768x457.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:457;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:20:\"Pizza-1-1024x609.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:609;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:4:\"Size\";a:4:{s:4:\"file\";s:19:\"Pizza-1-400x400.jpg\";s:5:\"width\";i:400;s:6:\"height\";i:400;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"custom_logo\";a:4:{s:4:\"file\";s:19:\"Pizza-1-800x600.jpg\";s:5:\"width\";i:800;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:2:\"18\";s:6:\"credit\";s:12:\"carlos valle\";s:6:\"camera\";s:28:\"Ixpress 132C - Hasselblad H1\";s:7:\"caption\";s:18:\"Caprese_Pizza_ 012\";s:17:\"created_timestamp\";s:10:\"1325030400\";s:9:\"copyright\";s:24:\"Carlos Valle Photography\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:3:\"100\";s:13:\"shutter_speed\";s:5:\"0.008\";s:5:\"title\";s:18:\"Caprese_Pizza_ 012\";s:11:\"orientation\";s:1:\"1\";s:8:\"keywords\";a:0:{}}}'),
(614, 160, '_wp_attached_file', '2017/12/Pizza-1-1.jpg'),
(615, 160, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:2322;s:6:\"height\";i:1382;s:4:\"file\";s:21:\"2017/12/Pizza-1-1.jpg\";s:5:\"sizes\";a:6:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:21:\"Pizza-1-1-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:21:\"Pizza-1-1-300x179.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:179;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:21:\"Pizza-1-1-768x457.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:457;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:22:\"Pizza-1-1-1024x609.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:609;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:4:\"Size\";a:4:{s:4:\"file\";s:21:\"Pizza-1-1-400x400.jpg\";s:5:\"width\";i:400;s:6:\"height\";i:400;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"custom_logo\";a:4:{s:4:\"file\";s:21:\"Pizza-1-1-800x600.jpg\";s:5:\"width\";i:800;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:2:\"18\";s:6:\"credit\";s:12:\"carlos valle\";s:6:\"camera\";s:28:\"Ixpress 132C - Hasselblad H1\";s:7:\"caption\";s:18:\"Caprese_Pizza_ 012\";s:17:\"created_timestamp\";s:10:\"1325030400\";s:9:\"copyright\";s:24:\"Carlos Valle Photography\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:3:\"100\";s:13:\"shutter_speed\";s:5:\"0.008\";s:5:\"title\";s:18:\"Caprese_Pizza_ 012\";s:11:\"orientation\";s:1:\"1\";s:8:\"keywords\";a:0:{}}}'),
(616, 161, '_wp_attached_file', '2017/12/pizza.jpg'),
(617, 161, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:1920;s:6:\"height\";i:1080;s:4:\"file\";s:17:\"2017/12/pizza.jpg\";s:5:\"sizes\";a:6:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:17:\"pizza-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:17:\"pizza-300x169.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:169;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:17:\"pizza-768x432.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:432;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:18:\"pizza-1024x576.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:576;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:4:\"Size\";a:4:{s:4:\"file\";s:17:\"pizza-400x400.jpg\";s:5:\"width\";i:400;s:6:\"height\";i:400;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"custom_logo\";a:4:{s:4:\"file\";s:17:\"pizza-800x600.jpg\";s:5:\"width\";i:800;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"1\";s:8:\"keywords\";a:0:{}}}'),
(618, 162, '_wp_attached_file', '2017/12/pizza-.jpg'),
(619, 162, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:400;s:6:\"height\";i:351;s:4:\"file\";s:18:\"2017/12/pizza-.jpg\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:18:\"pizza--150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:18:\"pizza--300x263.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:263;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:4:\"Size\";a:4:{s:4:\"file\";s:18:\"pizza--400x351.jpg\";s:5:\"width\";i:400;s:6:\"height\";i:351;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(620, 163, '_wp_attached_file', '2017/12/pizzas02.jpg'),
(621, 163, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:800;s:6:\"height\";i:800;s:4:\"file\";s:20:\"2017/12/pizzas02.jpg\";s:5:\"sizes\";a:5:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:20:\"pizzas02-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:20:\"pizzas02-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:20:\"pizzas02-768x768.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:768;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:4:\"Size\";a:4:{s:4:\"file\";s:20:\"pizzas02-400x400.jpg\";s:5:\"width\";i:400;s:6:\"height\";i:400;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"custom_logo\";a:4:{s:4:\"file\";s:20:\"pizzas02-800x600.jpg\";s:5:\"width\";i:800;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(622, 164, '_wp_attached_file', '2017/12/verfotoc.jpg'),
(623, 164, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:960;s:6:\"height\";i:960;s:4:\"file\";s:20:\"2017/12/verfotoc.jpg\";s:5:\"sizes\";a:5:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:20:\"verfotoc-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:20:\"verfotoc-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:20:\"verfotoc-768x768.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:768;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:4:\"Size\";a:4:{s:4:\"file\";s:20:\"verfotoc-400x400.jpg\";s:5:\"width\";i:400;s:6:\"height\";i:400;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"custom_logo\";a:4:{s:4:\"file\";s:20:\"verfotoc-800x600.jpg\";s:5:\"width\";i:800;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(624, 156, '_wp_trash_meta_status', 'publish'),
(625, 156, '_wp_trash_meta_time', '1513895338'),
(626, 156, '_wp_desired_post_slug', 'borrador-creado-el-20-december-2017-a-las-557-pm'),
(627, 167, '_edit_last', '1'),
(628, 167, '_thumbnail_id', '164'),
(629, 167, '_edit_lock', '1513897273:1'),
(630, 168, '_edit_last', '1'),
(631, 168, '_thumbnail_id', '163'),
(632, 168, '_edit_lock', '1513897254:1'),
(633, 169, '_edit_last', '1'),
(634, 169, '_thumbnail_id', '160'),
(635, 169, '_edit_lock', '1513897239:1'),
(636, 171, '_edit_last', '1'),
(637, 171, '_thumbnail_id', '162'),
(638, 171, '_edit_lock', '1513899099:1'),
(639, 172, '_edit_last', '1'),
(640, 172, '_edit_lock', '1513899138:1'),
(641, 172, '_thumbnail_id', '157'),
(642, 173, '_wp_attached_file', '2017/12/logoavpn.png'),
(643, 173, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:150;s:6:\"height\";i:150;s:4:\"file\";s:20:\"2017/12/logoavpn.png\";s:5:\"sizes\";a:0:{}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(644, 174, '_wp_attached_file', '2017/12/VERACE.png'),
(645, 174, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:298;s:6:\"height\";i:169;s:4:\"file\";s:18:\"2017/12/VERACE.png\";s:5:\"sizes\";a:1:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:18:\"VERACE-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(646, 175, '_wp_attached_file', '2017/12/excelenciatripadvisor.png'),
(647, 175, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:286;s:6:\"height\";i:369;s:4:\"file\";s:33:\"2017/12/excelenciatripadvisor.png\";s:5:\"sizes\";a:2:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:33:\"excelenciatripadvisor-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:6:\"medium\";a:4:{s:4:\"file\";s:33:\"excelenciatripadvisor-233x300.png\";s:5:\"width\";i:233;s:6:\"height\";i:300;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(648, 176, '_wp_attached_file', '2017/12/certificado-de-excelencia_ESP.png'),
(649, 176, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:150;s:6:\"height\";i:150;s:4:\"file\";s:41:\"2017/12/certificado-de-excelencia_ESP.png\";s:5:\"sizes\";a:0:{}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(650, 177, '_edit_last', '1'),
(651, 177, '_thumbnail_id', '162'),
(652, 177, '_edit_lock', '1513981196:1'),
(653, 177, '_wp_trash_meta_status', 'publish'),
(654, 177, '_wp_trash_meta_time', '1513981346'),
(655, 177, '_wp_desired_post_slug', '177'),
(656, 178, '_edit_last', '1'),
(657, 178, '_edit_lock', '1513994363:1'),
(658, 179, '_edit_last', '1'),
(659, 179, '_edit_lock', '1513994352:1'),
(660, 179, '_wp_trash_meta_status', 'publish'),
(661, 179, '_wp_trash_meta_time', '1513994876'),
(662, 179, '_wp_desired_post_slug', 'lol'),
(663, 181, '_edit_last', '1'),
(664, 181, '_edit_lock', '1513994786:1'),
(665, 184, '_wp_attached_file', '2017/12/fc105214e631d6c9f10c73e91815b4fd.jpg'),
(666, 184, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:594;s:6:\"height\";i:650;s:4:\"file\";s:44:\"2017/12/fc105214e631d6c9f10c73e91815b4fd.jpg\";s:5:\"sizes\";a:4:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:44:\"fc105214e631d6c9f10c73e91815b4fd-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:44:\"fc105214e631d6c9f10c73e91815b4fd-274x300.jpg\";s:5:\"width\";i:274;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:4:\"Size\";a:4:{s:4:\"file\";s:44:\"fc105214e631d6c9f10c73e91815b4fd-400x400.jpg\";s:5:\"width\";i:400;s:6:\"height\";i:400;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"custom_logo\";a:4:{s:4:\"file\";s:44:\"fc105214e631d6c9f10c73e91815b4fd-594x600.jpg\";s:5:\"width\";i:594;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(667, 154, '_wp_trash_meta_status', 'publish'),
(668, 154, '_wp_trash_meta_time', '1514464891'),
(669, 154, '_wp_desired_post_slug', 'pizza-veracce'),
(670, 153, '_wp_trash_meta_status', 'publish'),
(671, 153, '_wp_trash_meta_time', '1514464892'),
(672, 153, '_wp_desired_post_slug', 'pizza-ventura'),
(673, 186, '_edit_last', '1'),
(674, 186, '_edit_lock', '1515548132:1'),
(677, 186, 'tipo', 's/salsa: Pizza Blanca'),
(678, 186, '_tipo', 'field_5a2fe92395921'),
(679, 186, '_', 'field_5a55574275eb7'),
(680, 186, 'descripcion', 'muy bueno:Muy bueno.'),
(681, 186, '_descripcion', 'field_5a2ff06ce224c'),
(682, 190, '_edit_last', '1'),
(683, 190, '_edit_lock', '1515548922:1'),
(684, 190, 'tipo', 's/salsa: Pizza Blanca'),
(685, 190, '_tipo', 'field_5a2fe92395921'),
(686, 190, '_', 'field_5a55574275eb7'),
(687, 190, 'descripcion', 'muy bueno:Muy bueno.'),
(688, 190, '_descripcion', 'field_5a2ff06ce224c'),
(692, 190, 'precios', '6000'),
(693, 190, '_precios', 'field_5a2feffe97fe4'),
(696, 186, 'precios', '7000'),
(697, 186, '_precios', 'field_5a2feffe97fe4'),
(704, 149, 'rule', 'a:5:{s:5:\"param\";s:9:\"post_type\";s:8:\"operator\";s:2:\"==\";s:5:\"value\";s:7:\"product\";s:8:\"order_no\";i:0;s:8:\"group_no\";i:0;}'),
(705, 149, 'rule', 'a:5:{s:5:\"param\";s:9:\"post_type\";s:8:\"operator\";s:2:\"==\";s:5:\"value\";s:4:\"post\";s:8:\"order_no\";i:0;s:8:\"group_no\";i:1;}'),
(706, 149, 'rule', 'a:5:{s:5:\"param\";s:9:\"post_type\";s:8:\"operator\";s:2:\"==\";s:5:\"value\";s:4:\"post\";s:8:\"order_no\";i:0;s:8:\"group_no\";i:2;}'),
(707, 192, '_edit_last', '1'),
(708, 192, '_edit_lock', '1515551227:1'),
(709, 192, 'precios', '5500'),
(710, 192, '_precios', 'field_5a2feffe97fe4'),
(711, 193, '_edit_last', '1'),
(712, 193, '_edit_lock', '1515706287:1'),
(713, 193, 'precios', '6600'),
(714, 193, '_precios', 'field_5a2feffe97fe4'),
(715, 194, '_edit_last', '1'),
(716, 194, '_edit_lock', '1515706367:1'),
(717, 194, 'precios', '7300'),
(718, 194, '_precios', 'field_5a2feffe97fe4'),
(719, 195, '_edit_last', '1'),
(720, 195, '_edit_lock', '1515706514:1'),
(721, 195, 'precios', '5900'),
(722, 195, '_precios', 'field_5a2feffe97fe4'),
(723, 196, '_edit_last', '1'),
(724, 196, '_edit_lock', '1515706585:1'),
(725, 196, 'precios', '5900'),
(726, 196, '_precios', 'field_5a2feffe97fe4'),
(727, 197, '_edit_last', '1'),
(728, 197, '_edit_lock', '1515706657:1'),
(729, 197, 'precios', '6300'),
(730, 197, '_precios', 'field_5a2feffe97fe4'),
(731, 198, '_edit_last', '1'),
(732, 198, '_edit_lock', '1515706801:1'),
(733, 198, 'precios', '5900'),
(734, 198, '_precios', 'field_5a2feffe97fe4'),
(735, 199, '_edit_last', '1'),
(736, 199, '_edit_lock', '1515706845:1'),
(737, 199, 'precios', '6200'),
(738, 199, '_precios', 'field_5a2feffe97fe4');

-- --------------------------------------------------------

--
-- Table structure for table `dl_posts`
--

CREATE TABLE `dl_posts` (
  `ID` bigint(20) UNSIGNED NOT NULL,
  `post_author` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_title` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_excerpt` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'open',
  `post_password` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `post_name` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `to_ping` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `pinged` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_parent` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `guid` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `menu_order` int(11) NOT NULL DEFAULT '0',
  `post_type` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_count` bigint(20) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Dumping data for table `dl_posts`
--

INSERT INTO `dl_posts` (`ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(36, 1, '2017-11-27 18:43:53', '2017-11-28 00:43:53', '[select menu-558][text* your-name] </label>\r\n\r\n<label> Your Email (required)\r\n    [email* your-email] </label>\r\n\r\n<label> Subject\r\n    [text your-subject] </label>\r\n\r\n<label> Your Message\r\n    [textarea your-message] </label>\r\n<label>[file* file-409 filetypes:pdf|doc class:field]<label> Your Name (required)</label>\r\n[submit \"Send\"]\n1\nDesafio Latam \"[your-subject]\"\n[your-name] <jose.martinez.mayora@gmail.com>\njose.martinez.mayora@gmail.com\nFrom: [your-name] <[your-email]>\r\nSubject: [your-subject]\r\n\r\nMessage Body:\r\n[your-message]\r\n\r\n-- \r\nThis e-mail was sent from a contact form on Desafio Latam (http://localhost:8888)\nReply-To: [your-email]\n\n\n\n\nDesafio Latam \"[your-subject]\"\nDesafio Latam <jose.martinez.mayora@gmail.com>\n[your-email]\nMessage Body:\r\n[your-message]\r\n\r\n-- \r\nThis e-mail was sent from a contact form on Desafio Latam (http://localhost:8888)\nReply-To: jose.martinez.mayora@gmail.com\n\n\n\nThank you for your message. It has been sent.\nThere was an error trying to send your message. Please try again later.\nOne or more fields have an error. Please check and try again.\nThere was an error trying to send your message. Please try again later.\nYou must accept the terms and conditions before sending your message.\nThe field is required.\nThe field is too long.\nThe field is too short.\nThe date format is incorrect.\nThe date is before the earliest one allowed.\nThe date is after the latest one allowed.\nThere was an unknown error uploading the file.\nYou are not allowed to upload files of this type.\nThe file is too big.\nThere was an error uploading the file.\nThe number format is invalid.\nThe number is smaller than the minimum allowed.\nThe number is larger than the maximum allowed.\nThe answer to the quiz is incorrect.\nYour entered code is incorrect.\nThe e-mail address entered is invalid.\nThe URL is invalid.\nThe telephone number is invalid.', 'Contact form 1', '', 'publish', 'closed', 'closed', '', 'contact-form-1', '', '', '2017-12-10 07:57:19', '2017-12-10 13:57:19', '', 0, 'http://localhost:8888/?post_type=wpcf7_contact_form&#038;p=36', 0, 'wpcf7_contact_form', '', 0),
(110, 1, '2017-12-11 07:52:07', '2017-12-11 13:52:07', '<p style=\"text-align: left;\">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce dolor neque, vulputate euismod mollis eget, mattis eget augue. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Integer aliquam, est non porta maximus, dui mi aliquam urna, dapibus suscipit felis felis vitae turpis. Nulla in eros congue, scelerisque ante a, ullamcorper elit. Morbi semper, enim mollis fermentum volutpat, nisl quam malesuada metus, in varius enim metus ut ante. Pellentesque tincidunt, justo nec finibus bibendum, neque libero imperdiet elit, non condimentum neque felis vel urna. Integer sollicitudin mauris at lacinia elementum. Vivamus a tortor augue. Nam posuere diam eget orci posuere fermentum. Sed tempus feugiat sapien in varius. Etiam vel eros finibus, commodo neque eu, sollicitudin dui. Suspendisse bibendum vehicula mollis. Vivamus sagittis imperdiet eros, nec accumsan eros scelerisque eget.</p>\r\n<p style=\"text-align: left;\">Donec pretium, mi vitae viverra auctor, nibh metus semper elit, non venenatis erat tortor rhoncus velit. Sed condimentum sapien ac semper posuere. Pellentesque malesuada eleifend augue, at congue velit ullamcorper ac. Cras non eros eget massa pretium efficitur at in sapien. In accumsan odio non tortor ullamcorper, eu vestibulum felis commodo. In lorem ex, dictum vitae imperdiet in, egestas sed dolor. Praesent cursus sem metus, in venenatis leo placerat id. Integer pellentesque consectetur turpis, at auctor enim tempus a. Fusce sit amet lorem et tellus vestibulum semper.</p>\r\n<p style=\"text-align: left;\">Morbi sodales libero eros, vel pretium ex auctor vel. Sed consectetur convallis viverra. Nulla elementum nibh at ipsum aliquet, vitae tempus dolor efficitur. Nam hendrerit at purus sed dignissim. Ut accumsan diam ut porttitor posuere. Sed in lorem eu dolor sodales iaculis ac eu massa. In hac habitasse platea dictumst. Vestibulum sit amet erat ullamcorper, euismod neque tincidunt, rutrum ligula. Mauris condimentum, metus a sagittis tincidunt, quam enim semper orci, eget rhoncus nisi mauris eget tellus.</p>\r\n<p style=\"text-align: left;\">Vestibulum sit amet sodales risus, ac aliquam neque. Pellentesque efficitur volutpat diam, vel luctus libero lacinia non. Integer euismod diam ut porttitor aliquam. Cras id malesuada orci. Proin at elit nec nisl posuere commodo sit amet et dui. Fusce tellus nibh, egestas vel porta vel, hendrerit sit amet sem. Morbi feugiat finibus urna. Vestibulum elementum vulputate rhoncus. Phasellus mattis tellus turpis, in hendrerit erat tempor vitae.</p>\r\n<p style=\"text-align: left;\">Ut sit amet massa at libero tristique rutrum rutrum ut justo. Fusce vitae vulputate justo. Duis imperdiet nulla sit amet nibh dignissim rhoncus. Donec eget scelerisque justo. In tincidunt commodo vulputate. Vestibulum a urna varius, vulputate diam quis, varius neque. Aenean lorem libero, imperdiet ut tristique at, malesuada quis nunc. Morbi id eleifend nulla.</p>\r\n<p style=\"text-align: left;\">Donec ac quam facilisis, dictum odio et, finibus odio. Nam bibendum eleifend porta. Integer rutrum, ligula et vehicula finibus, velit orci eleifend est, nec pretium urna massa id ligula. Donec consectetur ac elit vel pharetra. Praesent in purus sollicitudin turpis ullamcorper rhoncus. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Nulla facilisi. Nam in justo faucibus, suscipit lectus vel, posuere nulla. Curabitur feugiat a est feugiat aliquam. In porta arcu ut gravida consequat. Phasellus malesuada tortor vel lacus faucibus, in maximus dui aliquet.</p>\r\n<p style=\"text-align: left;\">Ut ullamcorper urna at risus bibendum, a mollis libero sollicitudin. Ut blandit molestie nunc vitae pretium. Etiam vel feugiat turpis. Donec nec sagittis ex, sed fringilla tortor. Integer ac egestas lacus, vitae molestie nunc. Nulla suscipit ex in fermentum fermentum. Praesent laoreet erat at velit pharetra suscipit. Maecenas ornare leo nunc, ut condimentum dolor fringilla ut. In tempor odio erat, id sollicitudin nunc tristique a. Mauris accumsan felis massa, eu bibendum odio finibus vitae.</p>', 'Esta es la primera noticia del blog', '', 'trash', 'closed', 'closed', '', 'esta-es-la-primera-noticia-del-blog__trashed', '', '', '2017-12-20 07:03:10', '2017-12-20 13:03:10', '', 0, 'http://localhost:8888/?post_type=news&#038;p=110', 0, 'news', '', 0),
(112, 1, '2017-12-11 07:52:35', '2017-12-11 13:52:35', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce dolor neque, vulputate euismod mollis eget, mattis eget augue. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Integer aliquam, est non porta maximus, dui mi aliquam urna, dapibus suscipit felis felis vitae turpis. Nulla in eros congue, scelerisque ante a, ullamcorper elit. Morbi semper, enim mollis fermentum volutpat, nisl quam malesuada metus, in varius enim metus ut ante. Pellentesque tincidunt, justo nec finibus bibendum, neque libero imperdiet elit, non condimentum neque felis vel urna. Integer sollicitudin mauris at lacinia elementum. Vivamus a tortor augue. Nam posuere diam eget orci posuere fermentum. Sed tempus feugiat sapien in varius. Etiam vel eros finibus, commodo neque eu, sollicitudin dui. Suspendisse bibendum vehicula mollis. Vivamus sagittis imperdiet eros, nec accumsan eros scelerisque eget.\r\n\r\nDonec pretium, mi vitae viverra auctor, nibh metus semper elit, non venenatis erat tortor rhoncus velit. Sed condimentum sapien ac semper posuere. Pellentesque malesuada eleifend augue, at congue velit ullamcorper ac. Cras non eros eget massa pretium efficitur at in sapien. In accumsan odio non tortor ullamcorper, eu vestibulum felis commodo. In lorem ex, dictum vitae imperdiet in, egestas sed dolor. Praesent cursus sem metus, in venenatis leo placerat id. Integer pellentesque consectetur turpis, at auctor enim tempus a. Fusce sit amet lorem et tellus vestibulum semper.\r\n\r\nMorbi sodales libero eros, vel pretium ex auctor vel. Sed consectetur convallis viverra. Nulla elementum nibh at ipsum aliquet, vitae tempus dolor efficitur. Nam hendrerit at purus sed dignissim. Ut accumsan diam ut porttitor posuere. Sed in lorem eu dolor sodales iaculis ac eu massa. In hac habitasse platea dictumst. Vestibulum sit amet erat ullamcorper, euismod neque tincidunt, rutrum ligula. Mauris condimentum, metus a sagittis tincidunt, quam enim semper orci, eget rhoncus nisi mauris eget tellus.\r\n\r\nVestibulum sit amet sodales risus, ac aliquam neque. Pellentesque efficitur volutpat diam, vel luctus libero lacinia non. Integer euismod diam ut porttitor aliquam. Cras id malesuada orci. Proin at elit nec nisl posuere commodo sit amet et dui. Fusce tellus nibh, egestas vel porta vel, hendrerit sit amet sem. Morbi feugiat finibus urna. Vestibulum elementum vulputate rhoncus. Phasellus mattis tellus turpis, in hendrerit erat tempor vitae.\r\n\r\nUt sit amet massa at libero tristique rutrum rutrum ut justo. Fusce vitae vulputate justo. Duis imperdiet nulla sit amet nibh dignissim rhoncus. Donec eget scelerisque justo. In tincidunt commodo vulputate. Vestibulum a urna varius, vulputate diam quis, varius neque. Aenean lorem libero, imperdiet ut tristique at, malesuada quis nunc. Morbi id eleifend nulla.\r\n\r\nDonec ac quam facilisis, dictum odio et, finibus odio. Nam bibendum eleifend porta. Integer rutrum, ligula et vehicula finibus, velit orci eleifend est, nec pretium urna massa id ligula. Donec consectetur ac elit vel pharetra. Praesent in purus sollicitudin turpis ullamcorper rhoncus. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Nulla facilisi. Nam in justo faucibus, suscipit lectus vel, posuere nulla. Curabitur feugiat a est feugiat aliquam. In porta arcu ut gravida consequat. Phasellus malesuada tortor vel lacus faucibus, in maximus dui aliquet.\r\n\r\nUt ullamcorper urna at risus bibendum, a mollis libero sollicitudin. Ut blandit molestie nunc vitae pretium. Etiam vel feugiat turpis. Donec nec sagittis ex, sed fringilla tortor. Integer ac egestas lacus, vitae molestie nunc. Nulla suscipit ex in fermentum fermentum. Praesent laoreet erat at velit pharetra suscipit. Maecenas ornare leo nunc, ut condimentum dolor fringilla ut. In tempor odio erat, id sollicitudin nunc tristique a. Mauris accumsan felis massa, eu bibendum odio finibus vitae.', 'Segunda entrada de blog', '', 'trash', 'closed', 'closed', '', 'segunda-entrada-de-blog__trashed', '', '', '2017-12-20 07:03:08', '2017-12-20 13:03:08', '', 0, 'http://localhost:8888/?post_type=news&#038;p=112', 0, 'news', '', 0),
(113, 1, '2017-12-11 07:52:48', '2017-12-11 13:52:48', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce dolor neque, vulputate euismod mollis eget, mattis eget augue. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Integer aliquam, est non porta maximus, dui mi aliquam urna, dapibus suscipit felis felis vitae turpis. Nulla in eros congue, scelerisque ante a, ullamcorper elit. Morbi semper, enim mollis fermentum volutpat, nisl quam malesuada metus, in varius enim metus ut ante. Pellentesque tincidunt, justo nec finibus bibendum, neque libero imperdiet elit, non condimentum neque felis vel urna. Integer sollicitudin mauris at lacinia elementum. Vivamus a tortor augue. Nam posuere diam eget orci posuere fermentum. Sed tempus feugiat sapien in varius. Etiam vel eros finibus, commodo neque eu, sollicitudin dui. Suspendisse bibendum vehicula mollis. Vivamus sagittis imperdiet eros, nec accumsan eros scelerisque eget.\r\n\r\nDonec pretium, mi vitae viverra auctor, nibh metus semper elit, non venenatis erat tortor rhoncus velit. Sed condimentum sapien ac semper posuere. Pellentesque malesuada eleifend augue, at congue velit ullamcorper ac. Cras non eros eget massa pretium efficitur at in sapien. In accumsan odio non tortor ullamcorper, eu vestibulum felis commodo. In lorem ex, dictum vitae imperdiet in, egestas sed dolor. Praesent cursus sem metus, in venenatis leo placerat id. Integer pellentesque consectetur turpis, at auctor enim tempus a. Fusce sit amet lorem et tellus vestibulum semper.\r\n\r\nMorbi sodales libero eros, vel pretium ex auctor vel. Sed consectetur convallis viverra. Nulla elementum nibh at ipsum aliquet, vitae tempus dolor efficitur. Nam hendrerit at purus sed dignissim. Ut accumsan diam ut porttitor posuere. Sed in lorem eu dolor sodales iaculis ac eu massa. In hac habitasse platea dictumst. Vestibulum sit amet erat ullamcorper, euismod neque tincidunt, rutrum ligula. Mauris condimentum, metus a sagittis tincidunt, quam enim semper orci, eget rhoncus nisi mauris eget tellus.\r\n\r\nVestibulum sit amet sodales risus, ac aliquam neque. Pellentesque efficitur volutpat diam, vel luctus libero lacinia non. Integer euismod diam ut porttitor aliquam. Cras id malesuada orci. Proin at elit nec nisl posuere commodo sit amet et dui. Fusce tellus nibh, egestas vel porta vel, hendrerit sit amet sem. Morbi feugiat finibus urna. Vestibulum elementum vulputate rhoncus. Phasellus mattis tellus turpis, in hendrerit erat tempor vitae.\r\n\r\nUt sit amet massa at libero tristique rutrum rutrum ut justo. Fusce vitae vulputate justo. Duis imperdiet nulla sit amet nibh dignissim rhoncus. Donec eget scelerisque justo. In tincidunt commodo vulputate. Vestibulum a urna varius, vulputate diam quis, varius neque. Aenean lorem libero, imperdiet ut tristique at, malesuada quis nunc. Morbi id eleifend nulla.\r\n\r\nDonec ac quam facilisis, dictum odio et, finibus odio. Nam bibendum eleifend porta. Integer rutrum, ligula et vehicula finibus, velit orci eleifend est, nec pretium urna massa id ligula. Donec consectetur ac elit vel pharetra. Praesent in purus sollicitudin turpis ullamcorper rhoncus. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Nulla facilisi. Nam in justo faucibus, suscipit lectus vel, posuere nulla. Curabitur feugiat a est feugiat aliquam. In porta arcu ut gravida consequat. Phasellus malesuada tortor vel lacus faucibus, in maximus dui aliquet.\r\n\r\nUt ullamcorper urna at risus bibendum, a mollis libero sollicitudin. Ut blandit molestie nunc vitae pretium. Etiam vel feugiat turpis. Donec nec sagittis ex, sed fringilla tortor. Integer ac egestas lacus, vitae molestie nunc. Nulla suscipit ex in fermentum fermentum. Praesent laoreet erat at velit pharetra suscipit. Maecenas ornare leo nunc, ut condimentum dolor fringilla ut. In tempor odio erat, id sollicitudin nunc tristique a. Mauris accumsan felis massa, eu bibendum odio finibus vitae.', 'Tercera entrada del blog', '', 'trash', 'closed', 'closed', '', 'tercera-entrada-del-blog__trashed', '', '', '2017-12-20 07:03:04', '2017-12-20 13:03:04', '', 0, 'http://localhost:8888/?post_type=news&#038;p=113', 0, 'news', '', 0),
(114, 1, '2017-12-11 09:34:02', '2017-12-11 15:34:02', '', 'Producto', '', 'publish', 'closed', 'closed', '', 'producto', '', '', '2017-12-11 09:34:02', '2017-12-11 15:34:02', '', 0, 'http://localhost:8888/?page_id=114', 0, 'page', '', 0),
(115, 1, '2017-12-11 09:34:02', '2017-12-11 15:34:02', '', 'Producto', '', 'inherit', 'closed', 'closed', '', '114-revision-v1', '', '', '2017-12-11 09:34:02', '2017-12-11 15:34:02', '', 114, 'http://localhost:8888/2017/12/11/114-revision-v1/', 0, 'revision', '', 0),
(116, 1, '2017-12-11 10:30:25', '2017-12-11 16:30:25', ' ', '', '', 'publish', 'closed', 'closed', '', '116', '', '', '2017-12-12 07:39:29', '2017-12-12 13:39:29', '', 0, 'http://localhost:8888/?p=116', 2, 'nav_menu_item', '', 0),
(122, 1, '2017-12-11 16:19:29', '2017-12-11 22:19:29', '', 'Nosotros', '', 'trash', 'closed', 'closed', '', 'nosotros__trashed-2', '', '', '2017-12-20 08:33:50', '2017-12-20 14:33:50', '', 0, 'http://localhost:8888/?page_id=122', 0, 'page', '', 0),
(123, 1, '2017-12-11 16:19:29', '2017-12-11 22:19:29', '', 'Nosotros', '', 'inherit', 'closed', 'closed', '', '122-revision-v1', '', '', '2017-12-11 16:19:29', '2017-12-11 22:19:29', '', 122, 'http://localhost:8888/2017/12/11/122-revision-v1/', 0, 'revision', '', 0),
(124, 1, '2017-12-11 16:19:37', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2017-12-11 16:19:37', '0000-00-00 00:00:00', '', 0, 'http://localhost:8888/?p=124', 1, 'nav_menu_item', '', 0),
(125, 1, '2017-12-11 16:20:02', '2017-12-11 22:20:02', '', 'Galeria', '', 'publish', 'closed', 'closed', '', 'galeria', '', '', '2017-12-11 16:20:02', '2017-12-11 22:20:02', '', 0, 'http://localhost:8888/?page_id=125', 0, 'page', '', 0),
(126, 1, '2017-12-11 16:20:02', '2017-12-11 22:20:02', '', 'Galeria', '', 'inherit', 'closed', 'closed', '', '125-revision-v1', '', '', '2017-12-11 16:20:02', '2017-12-11 22:20:02', '', 125, 'http://localhost:8888/2017/12/11/125-revision-v1/', 0, 'revision', '', 0),
(127, 1, '2017-12-11 16:20:33', '2017-12-11 22:20:33', ' ', '', '', 'publish', 'closed', 'closed', '', '127', '', '', '2017-12-12 07:39:29', '2017-12-12 13:39:29', '', 0, 'http://localhost:8888/?p=127', 4, 'nav_menu_item', '', 0),
(128, 1, '2017-12-11 16:20:33', '2017-12-11 22:20:33', ' ', '', '', 'publish', 'closed', 'closed', '', '128', '', '', '2017-12-12 07:39:29', '2017-12-12 13:39:29', '', 0, 'http://localhost:8888/?p=128', 3, 'nav_menu_item', '', 0),
(129, 1, '2017-12-12 06:49:43', '2017-12-12 12:49:43', '', 'Entrada 1', '', 'trash', 'open', 'open', '', 'entrada-1__trashed', '', '', '2017-12-20 11:43:46', '2017-12-20 17:43:46', '', 0, 'http://localhost:8888/?p=129', 0, 'post', '', 0),
(130, 1, '2017-12-12 06:49:43', '2017-12-12 12:49:43', '', 'Entrada 1', '', 'inherit', 'closed', 'closed', '', '129-revision-v1', '', '', '2017-12-12 06:49:43', '2017-12-12 12:49:43', '', 129, 'http://localhost:8888/2017/12/12/129-revision-v1/', 0, 'revision', '', 0),
(132, 1, '2017-12-12 07:15:11', '2017-12-12 13:15:11', '', 'Entrada 2', '', 'trash', 'open', 'open', '', 'entrada-2__trashed', '', '', '2017-12-20 11:43:46', '2017-12-20 17:43:46', '', 0, 'http://localhost:8888/?p=132', 0, 'post', '', 0),
(134, 1, '2017-12-12 07:15:11', '2017-12-12 13:15:11', '', 'Entrada 2', '', 'inherit', 'closed', 'closed', '', '132-revision-v1', '', '', '2017-12-12 07:15:11', '2017-12-12 13:15:11', '', 132, 'http://localhost:8888/2017/12/12/132-revision-v1/', 0, 'revision', '', 0),
(135, 1, '2017-12-12 07:15:47', '2017-12-12 13:15:47', '', 'Entrada 3', '', 'trash', 'open', 'open', '', 'entrada-3__trashed', '', '', '2017-12-20 11:43:46', '2017-12-20 17:43:46', '', 0, 'http://localhost:8888/?p=135', 0, 'post', '', 0),
(137, 1, '2017-12-12 07:15:47', '2017-12-12 13:15:47', '', 'Entrada 3', '', 'inherit', 'closed', 'closed', '', '135-revision-v1', '', '', '2017-12-12 07:15:47', '2017-12-12 13:15:47', '', 135, 'http://localhost:8888/2017/12/12/135-revision-v1/', 0, 'revision', '', 0),
(138, 1, '2017-12-12 07:31:02', '2017-12-12 13:31:02', '', 'Entrada 4', '', 'trash', 'open', 'open', '', 'entrada-4__trashed', '', '', '2017-12-20 11:43:46', '2017-12-20 17:43:46', '', 0, 'http://localhost:8888/?p=138', 0, 'post', '', 0),
(139, 1, '2017-12-12 07:31:02', '2017-12-12 13:31:02', '', 'Entrada 4', '', 'inherit', 'closed', 'closed', '', '138-revision-v1', '', '', '2017-12-12 07:31:02', '2017-12-12 13:31:02', '', 138, 'http://localhost:8888/2017/12/12/138-revision-v1/', 0, 'revision', '', 0),
(140, 1, '2017-12-12 07:31:22', '2017-12-12 13:31:22', '', 'Entrada 5', '', 'trash', 'open', 'open', '', 'entrada-5__trashed', '', '', '2017-12-20 11:43:46', '2017-12-20 17:43:46', '', 0, 'http://localhost:8888/?p=140', 0, 'post', '', 0),
(141, 1, '2017-12-12 07:31:22', '2017-12-12 13:31:22', '', 'Entrada 5', '', 'inherit', 'closed', 'closed', '', '140-revision-v1', '', '', '2017-12-12 07:31:22', '2017-12-12 13:31:22', '', 140, 'http://localhost:8888/2017/12/12/140-revision-v1/', 0, 'revision', '', 0),
(145, 1, '2017-12-12 07:38:18', '2017-12-12 13:38:18', '', 'Home', '', 'publish', 'closed', 'closed', '', 'home', '', '', '2017-12-12 07:38:18', '2017-12-12 13:38:18', '', 0, 'http://localhost:8888/?page_id=145', 0, 'page', '', 0),
(146, 1, '2017-12-12 07:38:18', '2017-12-12 13:38:18', '', 'Home', '', 'inherit', 'closed', 'closed', '', '145-revision-v1', '', '', '2017-12-12 07:38:18', '2017-12-12 13:38:18', '', 145, 'http://localhost:8888/2017/12/12/145-revision-v1/', 0, 'revision', '', 0),
(147, 1, '2017-12-12 07:38:24', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2017-12-12 07:38:24', '0000-00-00 00:00:00', '', 0, 'http://localhost:8888/?p=147', 1, 'nav_menu_item', '', 0),
(148, 1, '2017-12-12 07:39:29', '2017-12-12 13:39:29', ' ', '', '', 'publish', 'closed', 'closed', '', '148', '', '', '2017-12-12 07:39:29', '2017-12-12 13:39:29', '', 0, 'http://localhost:8888/?p=148', 1, 'nav_menu_item', '', 0),
(149, 1, '2017-12-12 08:39:22', '2017-12-12 14:39:22', '', 'Grupo de noticia', '', 'publish', 'closed', 'closed', '', 'acf_grupo-de-noticia', '', '', '2018-01-09 19:47:32', '2018-01-10 01:47:32', '', 0, 'http://localhost:8888/?post_type=acf&#038;p=149', 0, 'acf', '', 0),
(153, 1, '2017-12-12 09:12:05', '2017-12-12 15:12:05', '', 'Pizza Ventura', '', 'trash', 'closed', 'closed', '', 'pizza-ventura__trashed', '', '', '2017-12-28 06:41:32', '2017-12-28 12:41:32', '', 0, 'http://localhost:8888/?post_type=product&#038;p=153', 0, 'product', '', 0),
(154, 1, '2017-12-12 11:47:08', '2017-12-12 17:47:08', '', 'Pizza Veracce', '', 'trash', 'closed', 'closed', '', 'pizza-veracce__trashed', '', '', '2017-12-28 06:41:31', '2017-12-28 12:41:31', '', 0, 'http://localhost:8888/?post_type=product&#038;p=154', 0, 'product', '', 0),
(156, 1, '2017-12-20 12:00:05', '2017-12-20 18:00:05', '<img class=\"alignnone size-medium wp-image-164\" src=\"http://localhost:8888/wp-content/uploads/2017/12/verfotoc-300x300.jpg\" alt=\"\" width=\"300\" height=\"300\" />', 'Pizza Mediterranea', '', 'trash', 'closed', 'closed', '', 'borrador-creado-el-20-december-2017-a-las-557-pm__trashed', '', '', '2017-12-21 16:28:58', '2017-12-21 22:28:58', '', 0, 'http://localhost:8888/?post_type=galery&#038;p=156', 0, 'galery', '', 0),
(157, 1, '2017-12-20 11:57:46', '2017-12-20 17:57:46', '', 'camaron', '', 'inherit', 'open', 'closed', '', 'camaron', '', '', '2017-12-20 11:57:46', '2017-12-20 17:57:46', '', 156, 'http://localhost:8888/wp-content/uploads/2017/12/camaron.jpeg', 0, 'attachment', 'image/jpeg', 0),
(158, 1, '2017-12-20 11:58:02', '2017-12-20 17:58:02', '', 'g1', '', 'inherit', 'open', 'closed', '', 'g1', '', '', '2017-12-20 11:58:02', '2017-12-20 17:58:02', '', 156, 'http://localhost:8888/wp-content/uploads/2017/12/g1.png', 0, 'attachment', 'image/png', 0),
(159, 1, '2017-12-20 11:58:12', '2017-12-20 17:58:12', '', 'Caprese_Pizza_ 012', 'Caprese_Pizza_ 012', 'inherit', 'open', 'closed', '', 'caprese_pizza_-012', '', '', '2017-12-20 11:58:12', '2017-12-20 17:58:12', '', 156, 'http://localhost:8888/wp-content/uploads/2017/12/Pizza-1.jpg', 0, 'attachment', 'image/jpeg', 0),
(160, 1, '2017-12-20 11:58:24', '2017-12-20 17:58:24', '', 'Caprese_Pizza_ 012', 'Caprese_Pizza_ 012', 'inherit', 'open', 'closed', '', 'caprese_pizza_-012-2', '', '', '2017-12-20 11:58:24', '2017-12-20 17:58:24', '', 156, 'http://localhost:8888/wp-content/uploads/2017/12/Pizza-1-1.jpg', 0, 'attachment', 'image/jpeg', 0),
(161, 1, '2017-12-20 11:58:47', '2017-12-20 17:58:47', '', 'pizza', '', 'inherit', 'open', 'closed', '', 'pizza', '', '', '2017-12-20 11:58:47', '2017-12-20 17:58:47', '', 156, 'http://localhost:8888/wp-content/uploads/2017/12/pizza.jpg', 0, 'attachment', 'image/jpeg', 0),
(162, 1, '2017-12-20 11:59:02', '2017-12-20 17:59:02', '', 'pizza-', '', 'inherit', 'open', 'closed', '', 'pizza-2', '', '', '2017-12-20 11:59:02', '2017-12-20 17:59:02', '', 156, 'http://localhost:8888/wp-content/uploads/2017/12/pizza-.jpg', 0, 'attachment', 'image/jpeg', 0),
(163, 1, '2017-12-20 11:59:03', '2017-12-20 17:59:03', '', 'pizzas02', '', 'inherit', 'open', 'closed', '', 'pizzas02', '', '', '2017-12-20 11:59:03', '2017-12-20 17:59:03', '', 156, 'http://localhost:8888/wp-content/uploads/2017/12/pizzas02.jpg', 0, 'attachment', 'image/jpeg', 0),
(164, 1, '2017-12-20 11:59:06', '2017-12-20 17:59:06', '', 'verfotoc', '', 'inherit', 'open', 'closed', '', 'verfotoc', '', '', '2017-12-20 11:59:06', '2017-12-20 17:59:06', '', 156, 'http://localhost:8888/wp-content/uploads/2017/12/verfotoc.jpg', 0, 'attachment', 'image/jpeg', 0),
(167, 1, '2017-12-21 16:29:19', '2017-12-21 22:29:19', '', 'Pizza Mediterranea', '', 'publish', 'closed', 'closed', '', '167', '', '', '2017-12-21 17:03:29', '2017-12-21 23:03:29', '', 0, 'http://localhost:8888/?post_type=galery&#038;p=167', 0, 'galery', '', 0),
(168, 1, '2017-12-21 16:29:32', '2017-12-21 22:29:32', '', 'Pizza Rodeo', '', 'publish', 'closed', 'closed', '', '168', '', '', '2017-12-21 17:03:15', '2017-12-21 23:03:15', '', 0, 'http://localhost:8888/?post_type=galery&#038;p=168', 0, 'galery', '', 0),
(169, 1, '2017-12-21 16:29:43', '2017-12-21 22:29:43', '', 'Pizza capresse', '', 'publish', 'closed', 'closed', '', '169', '', '', '2017-12-21 17:02:59', '2017-12-21 23:02:59', '', 0, 'http://localhost:8888/?post_type=galery&#038;p=169', 0, 'galery', '', 0),
(171, 1, '2017-12-21 17:33:56', '2017-12-21 23:33:56', '', 'Pizza Pepperoni', '', 'publish', 'closed', 'closed', '', 'pizza-pepperoni', '', '', '2017-12-21 17:33:56', '2017-12-21 23:33:56', '', 0, 'http://localhost:8888/?post_type=galery&#038;p=171', 0, 'galery', '', 0),
(172, 1, '2017-12-21 17:34:32', '2017-12-21 23:34:32', '', 'Pizza Camaron', '', 'publish', 'closed', 'closed', '', 'pizza-camaron', '', '', '2017-12-21 17:34:32', '2017-12-21 23:34:32', '', 0, 'http://localhost:8888/?post_type=galery&#038;p=172', 0, 'galery', '', 0),
(173, 1, '2017-12-21 17:39:21', '2017-12-21 23:39:21', '', 'logoavpn', '', 'inherit', 'open', 'closed', '', 'logoavpn', '', '', '2017-12-21 17:39:21', '2017-12-21 23:39:21', '', 0, 'http://localhost:8888/wp-content/uploads/2017/12/logoavpn.png', 0, 'attachment', 'image/png', 0),
(174, 1, '2017-12-21 17:39:50', '2017-12-21 23:39:50', '', 'VERACE', '', 'inherit', 'open', 'closed', '', 'verace', '', '', '2017-12-21 17:39:50', '2017-12-21 23:39:50', '', 0, 'http://localhost:8888/wp-content/uploads/2017/12/VERACE.png', 0, 'attachment', 'image/png', 0),
(175, 1, '2017-12-21 17:39:58', '2017-12-21 23:39:58', '', 'excelenciatripadvisor', '', 'inherit', 'open', 'closed', '', 'excelenciatripadvisor', '', '', '2017-12-21 17:39:58', '2017-12-21 23:39:58', '', 0, 'http://localhost:8888/wp-content/uploads/2017/12/excelenciatripadvisor.png', 0, 'attachment', 'image/png', 0),
(176, 1, '2017-12-21 17:40:38', '2017-12-21 23:40:38', '', 'certificado-de-excelencia_ESP', '', 'inherit', 'open', 'closed', '', 'certificado-de-excelencia_esp', '', '', '2017-12-21 17:40:38', '2017-12-21 23:40:38', '', 0, 'http://localhost:8888/wp-content/uploads/2017/12/certificado-de-excelencia_ESP.png', 0, 'attachment', 'image/png', 0),
(177, 1, '2017-12-22 16:21:50', '2017-12-22 22:21:50', 'sfddfdsfs', '', '', 'trash', 'closed', 'closed', '', '177__trashed', '', '', '2017-12-22 16:22:26', '2017-12-22 22:22:26', '', 0, 'http://localhost:8888/?post_type=news&#038;p=177', 0, 'news', '', 0),
(178, 1, '2017-12-22 16:33:42', '2017-12-22 22:33:42', 'Si googleas “origen de la pizza”, lo primero que aparece un breve relato de la invención de la pizza <a href=\"https://www.sabrosia.com/?s=pizza+margherita\">Margherita</a>, una pizza que <strong>representa los colores de la bandera italiana</strong>, el <strong>verde</strong>, por la albahaca; el <strong>blanco</strong>, por el queso mozzarella y el <strong>rojo</strong> por los tomates. (Si ya se te hizo agua la boca, espera a lo que viene).\r\n\r\nLas pizzas deben ser uno de los platos más apetecidos por todo el mundo, pero <strong>encontrar una buena pizza, es complejo,</strong> sobre todo porque en la actualidad cada uno cree tener la verdad.\r\n\r\nEl problema es lograr dar con una <strong>pizza espectacular</strong>, o que cumpla con los cánones mínimos: una masa delgada, pero crujiente, un queso fundido a punto y una salsa de tomate, de preferencia natural. En síntesis, <strong>pocos ingredientes, pero de buena calidad. </strong>\r\n\r\nPor suerte en octubre de este año llegó al <strong>barrio Manuel Montt</strong>, en Santiago de Chile, un <strong>horno “Acunto”, </strong>el mismo que usan los pizzaiolos originales y que fue traído directamente desde Italia a la <a href=\"http://www.pizzeriadomani.cl/\">pizzería Domani</a>.\r\n\r\n&nbsp;\r\n<p class=\"wp-caption-text\">Pizzería Domani</p>\r\nEste horno, fabricado de ladrillo y sal, de manera artesanal funciona bordeando los 500°C, lo que permite obtener <strong>pizzas listas en 1 minuto y medio y que lleguen chirreantes a la mesa</strong>.\r\n\r\nFuimos a conocer esta pizzería, la única en Chile, que cuenta con chefs certificados por la <strong>Associazione Verace Pizza Napoletana (AVPN)</strong>, la asociación de pizzeros más importante del mundo.\r\n\r\n&nbsp;\r\n<p class=\"wp-caption-text\">Pizzería Domani</p>\r\nAllí aprendieron las características esenciales de la <strong>pizza napoletana</strong>, lo primero es una <strong>corteza aireada, con manchas de leopardo, y un centro elástico y delgado</strong>.\r\n\r\nEn <a href=\"http://www.pizzeriadomani.cl/\">Domani</a>, <strong>todas las pizzas se preparan con masa madre</strong>, la que se somete a un período de <strong>fermentación de 24 horas y sólo se retoma 3 o 4 horas antes de ser usada</strong>, y además es libre de materia grasa.\r\n\r\nVarias de las pizzas de la carta, al igual que muchas de las materias primas que utilizan tienen <strong>dominación de origen protegida (DOP)</strong>, esto significa que los productos provienen de una región geográfica específica.\r\n\r\n&nbsp;\r\n<p class=\"wp-caption-text\">Pizza Costeña ($8.200)</p>\r\nDesde la entrada, la infraestructura sorprende y no es para menos, pues <strong>se ubica en una casa de 100 años</strong>, las paredes son gruesas y el espacio es amplio, tiene dos pisos y una terraza. Al fondo del primer piso está el horno, imponente, extraordinario.\r\n\r\nNos sentamos cerca del horno, por supuesto, para ver el proceso de cocción de las pizzas y comprobamos que efectivamente <strong>se demoran poco más de 1 minuto en estar listas, y el aroma era alucinante</strong>.\r\n\r\n&nbsp;\r\n<p class=\"wp-caption-text\">Pizza Costeña ($8.200) y Mediterránea ($6.600)</p>\r\nMientras esperábamos salieron dos exquisiteces: la pizza <strong>Costeña</strong> ($8.200), que lleva camarones y salmón; y la <strong>Mediterránea</strong> ($6.600), con queso de cabra, pimentón, aceitunas y rúcula.\r\n\r\nProbamos la pizza <strong>Margherita verace</strong> ($7.200), de <strong>mozzarella de bufala </strong>(DOP), <strong>salsa pomodoro</strong> (DOP), <strong>albahaca</strong> y <strong>aceite de oliva</strong>. Cuando llegó a la mesa, humeaba y el queso liberaba pequeñas burbujas.\r\n\r\nTambién pedimos la pizza <strong>Griega</strong> ($6.100), con <strong>salsa de tomate, mozzarella, queso de cabra, berenjenas en rodajas y cebolla</strong>. No pudimos decidir cuál de las dos era mejor que la otra, pero porque ambas superaban todas las pizzas que conocíamos hasta el minuto.', 'Pizzería Domani: La pequeña Italia de Chile.', '', 'publish', 'closed', 'closed', '', 'pizzeria-domani-la-pequena-italia-de-chile', '', '', '2017-12-22 20:01:45', '2017-12-23 02:01:45', '', 0, 'http://localhost:8888/?post_type=news&#038;p=178', 0, 'news', '', 0),
(179, 1, '2017-12-22 19:52:45', '2017-12-23 01:52:45', 'oshasjhjshdsoad', 'LOL', '', 'trash', 'closed', 'closed', '', 'lol__trashed', '', '', '2017-12-22 20:07:56', '2017-12-23 02:07:56', '', 0, 'http://localhost:8888/?post_type=news&#038;p=179', 0, 'news', '', 0),
(181, 1, '2017-12-22 20:08:46', '2017-12-23 02:08:46', '<p dir=\"ltr\">Buenas noticias para todos los fanáticos de la auténtica cocina italiana.</p>\r\n<p dir=\"ltr\">Este miércoles 12 de octubre, abre sus puertas la nueva pizzería Domani, en medio del barrio gastronómico de Manuel Montt, que pretende  hacer vivir a sus comensales una verdadera experiencia napolitana en su gastronomía, ambientación y barra internacional.</p>\r\n<p dir=\"ltr\">Lo diferente de Domani es que dos de sus pizzaiolos se certificaron en la asociación de pizzeros más importante del mundo, la Associazione Verace Pizza Napoletana (AVPN), siendo los primeros chilenos en obtener este acreditación.</p>\r\n<p dir=\"ltr\">“La propuesta gastronómica de Domani busca rescatar toda la tradición de las pizzerías napolitanas. (...) nos hemos preocupado de contar con los mejores ingredientes para preparar la verdadera pizza al estilo napolitano, trabajando con productos  con denominación de origen protegida (DOP) traídos desde Italia”, explica el socio y pizzaiolo de Domani, Sebastián Pérez, uno de los certificados.</p>\r\n<p dir=\"ltr\">“En Domani queremos generar la sensación de estar comiendo en una verdadera pizzería de Nápoles, por lo que la ambientación ha sido primordial y nos hemos preocupados de todos los detalles para entregar esa sensación y experiencia a todos las personas\" agregó.</p>\r\n<p dir=\"ltr\">Puedes visitarlos en Granaderos 1328, Providencia, a pasos del metro Manuel Montt. Además de pizzas, ofrecen una carta mediterránea simple y rica, con antipastos, ensaladas, platos de la casa y almuerzos que cambian semanalmente y se pueden encontrar a base de pastas, salmón, carnes, jaibas, verduras, entre otras.</p>', 'Cuchareando en Domani', '', 'publish', 'closed', 'closed', '', 'cuchareando-en-domani', '', '', '2017-12-22 20:08:46', '2017-12-23 02:08:46', '', 0, 'http://localhost:8888/?post_type=news&#038;p=181', 0, 'news', '', 0),
(184, 1, '2017-12-28 06:40:49', '2017-12-28 12:40:49', '', 'fc105214e631d6c9f10c73e91815b4fd', '', 'inherit', 'open', 'closed', '', 'fc105214e631d6c9f10c73e91815b4fd', '', '', '2017-12-28 06:40:49', '2017-12-28 12:40:49', '', 0, 'http://localhost:8888/wp-content/uploads/2017/12/fc105214e631d6c9f10c73e91815b4fd.jpg', 0, 'attachment', 'image/jpeg', 0),
(185, 1, '2018-01-09 16:23:12', '0000-00-00 00:00:00', '', 'Borrador automático', '', 'auto-draft', 'open', 'open', '', '', '', '', '2018-01-09 16:23:12', '0000-00-00 00:00:00', '', 0, 'http://localhost:8888/?p=185', 0, 'post', '', 0),
(186, 1, '2018-01-09 16:38:06', '2018-01-09 22:38:06', 'Salsa San Marzano, Queso bufala, hojas de albahacas y aceite de oliva.', 'Pizza Verace', '', 'publish', 'closed', 'closed', '', 'pizza-verace', '', '', '2018-01-09 19:11:30', '2018-01-10 01:11:30', '', 0, 'http://localhost:8888/?post_type=product&#038;p=186', 0, 'product', '', 0),
(187, 1, '2018-01-09 16:32:08', '0000-00-00 00:00:00', '', 'Borrador automático', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2018-01-09 16:32:08', '0000-00-00 00:00:00', '', 0, 'http://localhost:8888/?post_type=product&p=187', 0, 'product', '', 0),
(188, 1, '2018-01-09 16:33:17', '0000-00-00 00:00:00', '', 'Borrador automático', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2018-01-09 16:33:17', '0000-00-00 00:00:00', '', 0, 'http://localhost:8888/?post_type=product&p=188', 0, 'product', '', 0),
(190, 1, '2018-01-09 17:51:21', '2018-01-09 23:51:21', 'Salsa Pomodoro, queso mozzarella, rúcula, pimentón rojo, aceitunas negras, queso de cabra y aceite de oliva', 'Pizza Mediterranea', '', 'publish', 'closed', 'closed', '', 'pizza-mediterranea', '', '', '2018-01-09 18:03:53', '2018-01-10 00:03:53', '', 0, 'http://localhost:8888/?post_type=product&#038;p=190', 0, 'product', '', 0),
(191, 1, '2018-01-09 19:46:11', '0000-00-00 00:00:00', '', 'Borrador automático', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2018-01-09 19:46:11', '0000-00-00 00:00:00', '', 0, 'http://localhost:8888/?post_type=product&p=191', 0, 'product', '', 0),
(192, 1, '2018-01-09 20:29:27', '2018-01-10 02:29:27', 'Salsa Pomodoro, queso mozzarella, tocino, champiñón, carne, queso parmesano y aceite de oliva', 'Pizza Rodeo', '', 'publish', 'closed', 'closed', '', 'pizza-rodeo', '', '', '2018-01-09 20:29:27', '2018-01-10 02:29:27', '', 0, 'http://localhost:8888/?post_type=product&#038;p=192', 0, 'product', '', 0),
(193, 1, '2018-01-11 15:32:18', '2018-01-11 21:32:18', 'Salsa pomodoro, Queso mozzarella, salami, tocino y carne.', 'Pizza Carnaval', '', 'publish', 'closed', 'closed', '', 'pizza-carnaval', '', '', '2018-01-11 15:33:49', '2018-01-11 21:33:49', '', 0, 'http://localhost:8888/?post_type=product&#038;p=193', 0, 'product', '', 0),
(194, 1, '2018-01-11 15:35:08', '2018-01-11 21:35:08', 'Salsa Pomodoro, Queso mozzarella, rúcula, Prosciutto,  Queso de cabra.', 'Pizza Iberica', '', 'publish', 'closed', 'closed', '', 'pizza-iberica', '', '', '2018-01-11 15:35:08', '2018-01-11 21:35:08', '', 0, 'http://localhost:8888/?post_type=product&#038;p=194', 0, 'product', '', 0),
(195, 1, '2018-01-11 15:37:12', '2018-01-11 21:37:12', 'Salsa Pomodoro, Queso mozzarella, pepperoni, champiñón, pimenton verde, cebolla morada.', 'Pizza Torino', '', 'publish', 'closed', 'closed', '', 'pizza-torino', '', '', '2018-01-11 15:37:12', '2018-01-11 21:37:12', '', 0, 'http://localhost:8888/?post_type=product&#038;p=195', 0, 'product', '', 0),
(196, 1, '2018-01-11 15:38:41', '2018-01-11 21:38:41', 'Salsa Pomodoro, Queso mozzarella, jamón, piña', 'Pizza Hawaiana', '', 'publish', 'closed', 'closed', '', 'pizza-hawaiana', '', '', '2018-01-11 15:38:41', '2018-01-11 21:38:41', '', 0, 'http://localhost:8888/?post_type=product&#038;p=196', 0, 'product', '', 0),
(197, 1, '2018-01-11 15:39:57', '2018-01-11 21:39:57', 'Salsa Pomodoro, Queso mozzarella, chorizo español, pimenton rojo y aceitunas negras.', 'Pizza Española', '', 'publish', 'closed', 'closed', '', 'pizza-espanola', '', '', '2018-01-11 15:39:57', '2018-01-11 21:39:57', '', 0, 'http://localhost:8888/?post_type=product&#038;p=197', 0, 'product', '', 0),
(198, 1, '2018-01-11 15:40:42', '2018-01-11 21:40:42', 'Salsa Pomodoro, Queso mozzarella,  rodajas de tomate y albahaca.', 'Pizza Capresse', '', 'publish', 'closed', 'closed', '', 'pizza-capresse', '', '', '2018-01-11 15:40:42', '2018-01-11 21:40:42', '', 0, 'http://localhost:8888/?post_type=product&#038;p=198', 0, 'product', '', 0),
(199, 1, '2018-01-11 15:43:07', '2018-01-11 21:43:07', 'Salsa Pomodoro, Queso mozzarella, jamón, pimenton rojo, palmito', 'Pizza Minga', '', 'publish', 'closed', 'closed', '', 'pizza-minga', '', '', '2018-01-11 15:43:07', '2018-01-11 21:43:07', '', 0, 'http://localhost:8888/?post_type=product&#038;p=199', 0, 'product', '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `dl_termmeta`
--

CREATE TABLE `dl_termmeta` (
  `meta_id` bigint(20) UNSIGNED NOT NULL,
  `term_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- --------------------------------------------------------

--
-- Table structure for table `dl_terms`
--

CREATE TABLE `dl_terms` (
  `term_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `slug` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Dumping data for table `dl_terms`
--

INSERT INTO `dl_terms` (`term_id`, `name`, `slug`, `term_group`) VALUES
(1, 'Sin categoría', 'sin-categoria', 0),
(2, 'Menú principal', 'menu-principal', 0),
(3, 'post-format-aside', 'post-format-aside', 0),
(10, 'Niños', 'ninos', 0),
(11, 'Adulto', 'adulto', 0);

-- --------------------------------------------------------

--
-- Table structure for table `dl_term_relationships`
--

CREATE TABLE `dl_term_relationships` (
  `object_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `term_taxonomy_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `term_order` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Dumping data for table `dl_term_relationships`
--

INSERT INTO `dl_term_relationships` (`object_id`, `term_taxonomy_id`, `term_order`) VALUES
(116, 2, 0),
(127, 2, 0),
(128, 2, 0),
(129, 1, 0),
(132, 1, 0),
(135, 1, 0),
(138, 1, 0),
(140, 1, 0),
(148, 2, 0);

-- --------------------------------------------------------

--
-- Table structure for table `dl_term_taxonomy`
--

CREATE TABLE `dl_term_taxonomy` (
  `term_taxonomy_id` bigint(20) UNSIGNED NOT NULL,
  `term_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `taxonomy` varchar(32) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `description` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `parent` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `count` bigint(20) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Dumping data for table `dl_term_taxonomy`
--

INSERT INTO `dl_term_taxonomy` (`term_taxonomy_id`, `term_id`, `taxonomy`, `description`, `parent`, `count`) VALUES
(1, 1, 'category', '', 0, 0),
(2, 2, 'nav_menu', '', 0, 4),
(3, 3, 'post_format', '', 0, 0),
(10, 10, 'post_tag', '', 0, 0),
(11, 11, 'post_tag', '', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `dl_usermeta`
--

CREATE TABLE `dl_usermeta` (
  `umeta_id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Dumping data for table `dl_usermeta`
--

INSERT INTO `dl_usermeta` (`umeta_id`, `user_id`, `meta_key`, `meta_value`) VALUES
(1, 1, 'nickname', 'JoseMatinez1860'),
(2, 1, 'first_name', ''),
(3, 1, 'last_name', ''),
(4, 1, 'description', ''),
(5, 1, 'rich_editing', 'true'),
(6, 1, 'syntax_highlighting', 'true'),
(7, 1, 'comment_shortcuts', 'false'),
(8, 1, 'admin_color', 'fresh'),
(9, 1, 'use_ssl', '0'),
(10, 1, 'show_admin_bar_front', 'false'),
(11, 1, 'locale', ''),
(12, 1, 'dl_capabilities', 'a:1:{s:13:\"administrator\";b:1;}'),
(13, 1, 'dl_user_level', '10'),
(14, 1, 'dismissed_wp_pointers', 'text_widget_custom_html'),
(15, 1, 'show_welcome_panel', '0'),
(16, 1, 'session_tokens', 'a:2:{s:64:\"2085aac827d1641614079af983edaf3016bcfe19d63b907194942810ea886399\";a:4:{s:10:\"expiration\";i:1515709388;s:2:\"ip\";s:9:\"127.0.0.1\";s:2:\"ua\";s:115:\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.132 Safari/537.36\";s:5:\"login\";i:1515536588;}s:64:\"f99037eac8bc24aa474ca7c6746eddfb7aa3865f311441aa7248847fae577fe4\";a:4:{s:10:\"expiration\";i:1515879039;s:2:\"ip\";s:9:\"127.0.0.1\";s:2:\"ua\";s:115:\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.132 Safari/537.36\";s:5:\"login\";i:1515706239;}}'),
(17, 1, 'dl_dashboard_quick_press_last_post_id', '185'),
(18, 1, 'community-events-location', 'a:1:{s:2:\"ip\";s:9:\"127.0.0.0\";}'),
(19, 1, 'dl_user-settings', 'libraryContent=browse&editor=tinymce&mfold=o&posts_list_mode=list&uploader=1'),
(20, 1, 'dl_user-settings-time', '1513983066'),
(21, 1, 'closedpostboxes_page', 'a:0:{}'),
(22, 1, 'metaboxhidden_page', 'a:5:{i:0;s:10:\"postcustom\";i:1;s:16:\"commentstatusdiv\";i:2;s:11:\"commentsdiv\";i:3;s:7:\"slugdiv\";i:4;s:9:\"authordiv\";}'),
(23, 1, 'managenav-menuscolumnshidden', 'a:5:{i:0;s:11:\"link-target\";i:1;s:11:\"css-classes\";i:2;s:3:\"xfn\";i:3;s:11:\"description\";i:4;s:15:\"title-attribute\";}'),
(24, 1, 'metaboxhidden_nav-menus', 'a:2:{i:0;s:18:\"add-post-type-news\";i:1;s:12:\"add-post_tag\";}'),
(25, 1, 'closedpostboxes_acf', 'a:0:{}'),
(26, 1, 'metaboxhidden_acf', 'a:1:{i:0;s:7:\"slugdiv\";}'),
(27, 1, 'closedpostboxes_post', 'a:0:{}'),
(28, 1, 'metaboxhidden_post', 'a:7:{i:0;s:6:\"acf_34\";i:1;s:11:\"postexcerpt\";i:2;s:13:\"trackbacksdiv\";i:3;s:10:\"postcustom\";i:4;s:16:\"commentstatusdiv\";i:5;s:7:\"slugdiv\";i:6;s:9:\"authordiv\";}'),
(29, 1, 'nav_menu_recently_edited', '2'),
(30, 1, 'closedpostboxes_dashboard', 'a:0:{}'),
(31, 1, 'metaboxhidden_dashboard', 'a:3:{i:0;s:18:\"dashboard_activity\";i:1;s:21:\"dashboard_quick_press\";i:2;s:17:\"dashboard_primary\";}'),
(32, 1, 'dl_media_library_mode', 'list'),
(33, 1, 'edit_news_per_page', '20');

-- --------------------------------------------------------

--
-- Table structure for table `dl_users`
--

CREATE TABLE `dl_users` (
  `ID` bigint(20) UNSIGNED NOT NULL,
  `user_login` varchar(60) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_pass` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_nicename` varchar(50) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_email` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_url` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT '0',
  `display_name` varchar(250) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Dumping data for table `dl_users`
--

INSERT INTO `dl_users` (`ID`, `user_login`, `user_pass`, `user_nicename`, `user_email`, `user_url`, `user_registered`, `user_activation_key`, `user_status`, `display_name`) VALUES
(1, 'JoseMatinez1860', '$P$BJnI4Lj.HxFbOK.T2dVacVShJqCc9n0', 'josematinez1860', 'jose.martinez.mayora@gmail.com', '', '2017-11-20 22:42:34', '', 0, 'JoseMatinez1860');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `dl_commentmeta`
--
ALTER TABLE `dl_commentmeta`
  ADD PRIMARY KEY (`meta_id`),
  ADD KEY `comment_id` (`comment_id`),
  ADD KEY `meta_key` (`meta_key`(191));

--
-- Indexes for table `dl_comments`
--
ALTER TABLE `dl_comments`
  ADD PRIMARY KEY (`comment_ID`),
  ADD KEY `comment_post_ID` (`comment_post_ID`),
  ADD KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  ADD KEY `comment_date_gmt` (`comment_date_gmt`),
  ADD KEY `comment_parent` (`comment_parent`),
  ADD KEY `comment_author_email` (`comment_author_email`(10));

--
-- Indexes for table `dl_db7_forms`
--
ALTER TABLE `dl_db7_forms`
  ADD PRIMARY KEY (`form_id`);

--
-- Indexes for table `dl_duplicator_packages`
--
ALTER TABLE `dl_duplicator_packages`
  ADD PRIMARY KEY (`id`),
  ADD KEY `hash` (`hash`);

--
-- Indexes for table `dl_ewwwio_images`
--
ALTER TABLE `dl_ewwwio_images`
  ADD UNIQUE KEY `id` (`id`),
  ADD KEY `path_image_size` (`path`(191),`image_size`),
  ADD KEY `attachment_info` (`gallery`(3),`attachment_id`);

--
-- Indexes for table `dl_links`
--
ALTER TABLE `dl_links`
  ADD PRIMARY KEY (`link_id`),
  ADD KEY `link_visible` (`link_visible`);

--
-- Indexes for table `dl_options`
--
ALTER TABLE `dl_options`
  ADD PRIMARY KEY (`option_id`),
  ADD UNIQUE KEY `option_name` (`option_name`);

--
-- Indexes for table `dl_phone2app_form`
--
ALTER TABLE `dl_phone2app_form`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `dl_phone2app_user`
--
ALTER TABLE `dl_phone2app_user`
  ADD PRIMARY KEY (`username`);

--
-- Indexes for table `dl_postmeta`
--
ALTER TABLE `dl_postmeta`
  ADD PRIMARY KEY (`meta_id`),
  ADD KEY `post_id` (`post_id`),
  ADD KEY `meta_key` (`meta_key`(191));

--
-- Indexes for table `dl_posts`
--
ALTER TABLE `dl_posts`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `post_name` (`post_name`(191)),
  ADD KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  ADD KEY `post_parent` (`post_parent`),
  ADD KEY `post_author` (`post_author`);

--
-- Indexes for table `dl_termmeta`
--
ALTER TABLE `dl_termmeta`
  ADD PRIMARY KEY (`meta_id`),
  ADD KEY `term_id` (`term_id`),
  ADD KEY `meta_key` (`meta_key`(191));

--
-- Indexes for table `dl_terms`
--
ALTER TABLE `dl_terms`
  ADD PRIMARY KEY (`term_id`),
  ADD KEY `slug` (`slug`(191)),
  ADD KEY `name` (`name`(191));

--
-- Indexes for table `dl_term_relationships`
--
ALTER TABLE `dl_term_relationships`
  ADD PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  ADD KEY `term_taxonomy_id` (`term_taxonomy_id`);

--
-- Indexes for table `dl_term_taxonomy`
--
ALTER TABLE `dl_term_taxonomy`
  ADD PRIMARY KEY (`term_taxonomy_id`),
  ADD UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  ADD KEY `taxonomy` (`taxonomy`);

--
-- Indexes for table `dl_usermeta`
--
ALTER TABLE `dl_usermeta`
  ADD PRIMARY KEY (`umeta_id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `meta_key` (`meta_key`(191));

--
-- Indexes for table `dl_users`
--
ALTER TABLE `dl_users`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `user_login_key` (`user_login`),
  ADD KEY `user_nicename` (`user_nicename`),
  ADD KEY `user_email` (`user_email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `dl_commentmeta`
--
ALTER TABLE `dl_commentmeta`
  MODIFY `meta_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `dl_comments`
--
ALTER TABLE `dl_comments`
  MODIFY `comment_ID` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `dl_db7_forms`
--
ALTER TABLE `dl_db7_forms`
  MODIFY `form_id` bigint(20) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `dl_duplicator_packages`
--
ALTER TABLE `dl_duplicator_packages`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `dl_ewwwio_images`
--
ALTER TABLE `dl_ewwwio_images`
  MODIFY `id` int(14) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=171;
--
-- AUTO_INCREMENT for table `dl_links`
--
ALTER TABLE `dl_links`
  MODIFY `link_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `dl_options`
--
ALTER TABLE `dl_options`
  MODIFY `option_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1235;
--
-- AUTO_INCREMENT for table `dl_postmeta`
--
ALTER TABLE `dl_postmeta`
  MODIFY `meta_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=739;
--
-- AUTO_INCREMENT for table `dl_posts`
--
ALTER TABLE `dl_posts`
  MODIFY `ID` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=200;
--
-- AUTO_INCREMENT for table `dl_termmeta`
--
ALTER TABLE `dl_termmeta`
  MODIFY `meta_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `dl_terms`
--
ALTER TABLE `dl_terms`
  MODIFY `term_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
--
-- AUTO_INCREMENT for table `dl_term_taxonomy`
--
ALTER TABLE `dl_term_taxonomy`
  MODIFY `term_taxonomy_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
--
-- AUTO_INCREMENT for table `dl_usermeta`
--
ALTER TABLE `dl_usermeta`
  MODIFY `umeta_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=34;
--
-- AUTO_INCREMENT for table `dl_users`
--
ALTER TABLE `dl_users`
  MODIFY `ID` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
